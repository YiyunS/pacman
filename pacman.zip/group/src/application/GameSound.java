package application;

import java.io.File;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class GameSound {
	
	public static File begin = new File("Sound/begining.WAV");
	
	public static File edot = new File("Sound/eatbean.WAV");
	
	public static File eheart = new File("Sound/eatheart.WAV");
	
	public static File death = new File("Sound/death.WAV");
	
	public static File eghost = new File("Sound/eatghost.WAV");
	
	public static File win = new File("Sound/win.WAV");
	
	public static File lose = new File("Sound/lose1.WAV");	
	
	public static void playSound(File sound) 
	{
		try 
		{
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(sound));
			clip.start();
			
			//Thread.sleep(clip.getMicrosecondLength()/1000);
		}
		catch(Exception e){}
	}
}
