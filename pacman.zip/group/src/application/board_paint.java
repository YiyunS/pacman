package application;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JButton;

public class board_paint 


{	
	public static int loseX = -40; 
	
	public static int winX = -400;
	
	public static boolean MoveRight = true;
	
	
	static final Font newFont = new Font("Comic Sans MS",Font.BOLD,30);
	
	
	static void setButton(JButton Button)
	{
		
		Button.setBounds(250, 550, 300, 80);
		Button.setForeground(Color.blue);
		Button.setBackground(Color.gray);
		Button.setFont(new Font("Comic Sans MS",Font.BOLD,50));
	}

	
	static void paint_inner_wall(Graphics paint, int[][] arr) 
	{	
		Color brown = new Color(153,102,0);

		for (int column = 0; column < 19; column++)
		{
			for (int row = 0;  row < 17; row++)
			{
				
				if (arr[column][row] ==  2)
				{
					paint.setColor(brown);
					paint.fillRect(column*40, row*40, 40, 40);
					
					paint.setColor(Color.black);
					paint.drawLine(column*40, row*40, column*40+40, row*40);
					
					paint.drawLine(column*40+10, row*40, column*40+10, row*40+10);					paint.drawLine(column*40+30, row*40, column*40+30, row*40+10);
					
					paint.drawLine(column*40, row*40+10, column*40+40, row*40+10);
					
					paint.drawLine(column*40, row*40+10, column*40, row*40+20);
					paint.drawLine(column*40+20, row*40+10, column*40+20, row*40+20);				
					paint.drawLine(column*40+39, row*40+10, column*40+39, row*40+20);
					
					paint.drawLine(column*40, row*40+20, column*40+40, row*40+20);
					
					paint.drawLine(column*40+10, row*40+20, column*40+10, row*40+30);				paint.drawLine(column*40+30, row*40+20, column*40+30, row*40+30);
					
					paint.drawLine(column*40, row*40+30, column*40+40, row*40+30);
					
					paint.drawLine(column*40, row*40+30, column*40, row*40+40);
					paint.drawLine(column*40+20, row*40+30, column*40+20, row*40+40);				
					paint.drawLine(column*40+39, row*40+30, column*40+39, row*40+40);
					
					
				}
			}
		}
		paint.setColor(Color.BLACK);
		paint.fillRect(360, 160, 40, 40);
		paint.setColor(Color.RED);
		paint.fillRect(358, 177, 44, 6);
		
		paint.setColor(Color.BLACK);
		paint.fillRect(360, 240, 40, 40);
		paint.setColor(Color.RED);
		paint.fillRect(358, 257, 44, 6);
	}
	
	static void paint_pac(Graphics paint, int px, int py,int pvx,int pvy, String face_to, int time)
	{
		
		//drawing pacman when move right
		if (face_to == "RIGHT") 
			{
			board_paint.paint_right_face(paint, px, py, time);
			}

		//drawing pacman when move left
		if (face_to == "LEFT")
			{
			board_paint.paint_left_face(paint, px, py, time);
			}
		
		//drawing pacman when move down
		if (face_to == "DOWN")
			{
			board_paint.paint_down_face(paint, px, py, time);
			}

		//drawing pacman when move up
		if (face_to == "UP")
			{		
			board_paint.paint_up_face(paint, px, py, time);
			}
	}
	
	//paint the face at beginning
	static void paint_normal_face(Graphics paint, int px, int py) 
	{	
		//set color
		paint.setColor(Color.yellow);
		
		//face
		paint.fillOval(px+5, py+5, 30, 30);
		//mouth
		paint.setColor(Color.BLACK);
		paint.fillRect(px, py+19, 40, 2);
		
		//eyes
		paint.fillOval(px+12, py+10, 4, 4);
		paint.fillOval(px+24, py+10, 4, 4);
		
		//tone
		paint.setColor(Color.pink);
		paint.fillArc(px+15, py+10, 10, 20, 180, 180);
		paint.setColor(Color.black);
		paint.drawArc(px+15, py+10, 10, 20, 180, 180);
		paint.drawLine(px+20, py+20, px+20, py+25);
		
	}
	
	static void paint_right_face(Graphics paint, int px, int py,int time) 
	{
		//set color
		paint.setColor(Color.yellow);
		
		// drawing face
		if(time % 50 <= 25)
		{
		paint.fillArc(px+5, py+5, 30, 30,15, 165);
		paint.fillArc(px+5, py+5, 30, 30,180, 155);}
		
		else
		{
			paint.fillArc(px+5, py+5, 30, 30,5, 175);
			paint.fillArc(px+5, py+5, 30, 30,180, 175);
		}
		//drawing eyes
		paint.setColor(Color.BLACK);
		paint.fillOval(px+20, py+10, 4, 4);
		
	}
	
	static void paint_left_face(Graphics paint, int px, int py, int time) 
	{
		//set color
		paint.setColor(Color.yellow);
		
		// drawing face
		if(time % 50 <= 25)
		{
		paint.fillArc(px+5, py+5, 30, 30,0, 175);
		paint.fillArc(px+5, py+5, 30, 30,185, 175);
		}
		else
		{
			paint.fillArc(px+5, py+5, 30, 30,0, 165);
			paint.fillArc(px+5, py+5, 30, 30,205, 155);
			
		}
		//drawing eyes
		paint.setColor(Color.BLACK);
		paint.fillOval(px+16, py+10, 4, 4);
		
	}
	
	static void paint_up_face(Graphics paint, int px, int py, int time) 
	{
		// drawing face
		paint.setColor(Color.yellow);
		paint.fillOval(px+5, py+5, 30, 30);
		
		//mouth
		if(time % 50 <= 25)
			{
			paint.setColor(Color.BLACK);
			paint.fillRect(px, py+16, 40, 8);
			}
		else
			{
			paint.setColor(Color.BLACK);
			paint.fillRect(px, py+23, 40, 2);
			}		
		//eyes
		paint.fillOval(px+12, py+8, 4, 4);
		paint.fillOval(px+24, py+8, 4, 4);
		
	}
	
	static void paint_down_face(Graphics paint, int px, int py, int time) 
	{
		// drawing face
		paint.setColor(Color.yellow);
		paint.fillOval(px+5, py+5, 30, 30);
				
		//mouth
		if(time % 50 <= 25)
		{
		paint.setColor(Color.BLACK);
		paint.fillRect(px, py+20, 40, 8);
		}
		else
		{
			paint.setColor(Color.BLACK);
			paint.fillRect(px, py+23, 40, 2);
		}
		//eyes
		paint.fillOval(px+12, py+12, 4, 4);
		paint.fillOval(px+24, py+12, 4, 4);
		
	
		
	}
	
	static void paint_beans(Graphics paint, int[][] arr)
	{	
		//int a  = 0;
		for (int column = 0; column < 19; column++)
		{
			for (int row = 0;  row < 17; row++)
			{
				paint.setColor(Color.WHITE);
				if (arr[column][row] ==  1)
				{
					paint.fillOval(column*40+17, row*40+17, 6, 6);
					//a++;
				}
			}
		}
		//System.out.println(a);
		
	}
	
	
	static void paint_big_beans(Graphics paint, int[][] arr,int time )
	{
		int[] xpoint = new int[3];
		int[] ypoint =  new int[3];
		
		for (int column = 0; column < 19; column++)
		{
			for (int row = 0;  row < 17; row++)
			{
				paint.setColor(Color.red);
				if (arr[column][row] ==  4)
				{
					if(time % 50 <= 25)
					{
					xpoint[0] = column*40+10;
					xpoint[1] = column*40+20;
					xpoint[2] = column*40+30;
				 
					ypoint[0] =row*40+20;
					ypoint[1] =row*40+30;
					ypoint[2] =row*40+20;
						 
			
					paint.fillArc(column*40+10,row*40+15,10,10,0,180);
					paint.fillArc(column*40+20,row*40+15,10,10,0,180);
				
					paint.fillPolygon(xpoint,ypoint, 3);
					}
				}
			}
		}
	}
	
	static void paint_sur_wall(Graphics paint)
	{
		paint.setColor(Color.blue);
		paint.fillRect(0, 0, 740, 40);
		
		paint.fillRect(0, 0, 40, 320);
		paint.fillRect(0, 360, 40, 300);
		
		paint.fillRect(0, 640, 740, 40);
		
		paint.fillRect(720, 0, 40, 320);
		paint.fillRect(720, 360, 40, 320);
	}
	
	static void Count_Points(Graphics paint, int score) 
	{
		paint.setColor(Color.white);
		paint.setFont(newFont);
		paint.drawString("Score: "+score, 570, 735);
	}
	
	public static void paint_kerry(Graphics paint,int kx, int ky, String kface, int time )
	{
		
		if(buff.getBuff())
		{
			
			if(time % 50 <= 25)
			paint.setColor(new Color(102,0,153));
			else
			paint.setColor(Color.green);
			
			//head
			paint.fillArc(kx+5, ky+5, 30, 20,0,180);
			//body
			paint.fillRect(kx+5, ky+15, 30, 15);
			//foots
			paint.fillArc(kx+5, ky+25, 10, 10, 180, 180);
			paint.fillArc(kx+15, ky+25, 10, 10, 180, 180);
			paint.fillArc(kx+25, ky+25, 10, 10, 180, 180);
			//eyes
			paint.setColor(Color.YELLOW);
			
			paint.drawLine(kx+10, ky+12,kx+14, ky+18);
			paint.drawLine(kx+14, ky+12,kx+10, ky+18);
			
			paint.drawLine(kx+26, ky+12,kx+30, ky+18);
			paint.drawLine(kx+30, ky+12,kx+26, ky+18);
			
			//mouse
			paint.drawLine(kx+8, ky+28,kx+11, ky+23);
			paint.drawLine(kx+11, ky+23,kx+14, ky+28);
			paint.drawLine(kx+14, ky+28,kx+17, ky+23);
			paint.drawLine(kx+17, ky+23,kx+20, ky+28);
			paint.drawLine(kx+20, ky+28,kx+23, ky+23);
			paint.drawLine(kx+23, ky+23,kx+26, ky+28);
			paint.drawLine(kx+26, ky+28,kx+29, ky+23);
			paint.drawLine(kx+29, ky+23,kx+32, ky+28);
			
		}
		
		else
		{
		paint.setColor(Color.green);
		
		//head
		paint.fillArc(kx+5, ky+5, 30, 20,0,180);
		//body
		paint.fillRect(kx+5, ky+15, 30, 15);
		//foots
		paint.fillArc(kx+5, ky+25, 10, 10, 180, 180);
		paint.fillArc(kx+15, ky+25, 10, 10, 180, 180);
		paint.fillArc(kx+25, ky+25, 10, 10, 180, 180);
		
		//paint eyes
		paint.setColor(Color.WHITE);
		
			paint.fillOval(kx+8, ky+10, 10, 20);
			paint.fillOval(kx+22, ky+10, 10, 20);
			
			paint.setColor(Color.black);
			
			paint.fillOval(kx+11, ky+13, 5, 10);
			paint.fillOval(kx+24, ky+13, 5, 10);
		
		
		}
		
	}
	
	public static void paint_david(Graphics paint,int kx, int ky, String kface, int time)
	{	
		
		
		if(buff.getBuff())
		{
			
			if(time % 50 <= 25)
			paint.setColor(new Color(102,0,153));
			else
			paint.setColor(new Color(51,204,255));
			
			//head
			paint.fillArc(kx+5, ky+5, 30, 20,0,180);
			//body
			paint.fillRect(kx+5, ky+15, 30, 15);
			//foots
			paint.fillArc(kx+5, ky+25, 10, 10, 180, 180);
			paint.fillArc(kx+15, ky+25, 10, 10, 180, 180);
			paint.fillArc(kx+25, ky+25, 10, 10, 180, 180);
			//eyes
			paint.setColor(Color.YELLOW);
			
			paint.drawLine(kx+10, ky+12,kx+14, ky+18);
			paint.drawLine(kx+14, ky+12,kx+10, ky+18);
			
			paint.drawLine(kx+26, ky+12,kx+30, ky+18);
			paint.drawLine(kx+30, ky+12,kx+26, ky+18);
			
			//mouse
			paint.drawLine(kx+8, ky+28,kx+11, ky+23);
			paint.drawLine(kx+11, ky+23,kx+14, ky+28);
			paint.drawLine(kx+14, ky+28,kx+17, ky+23);
			paint.drawLine(kx+17, ky+23,kx+20, ky+28);
			paint.drawLine(kx+20, ky+28,kx+23, ky+23);
			paint.drawLine(kx+23, ky+23,kx+26, ky+28);
			paint.drawLine(kx+26, ky+28,kx+29, ky+23);
			paint.drawLine(kx+29, ky+23,kx+32, ky+28);
			
		}
		
		else
		{
		
		
		
		paint.setColor(new Color(51,204,255));
		
		
		//head
		paint.fillArc(kx+5, ky+5, 30, 20,0,180);
		//body
		paint.fillRect(kx+5, ky+15, 30, 15);
		//foots
		paint.fillArc(kx+5, ky+25, 10, 10, 180, 180);
		paint.fillArc(kx+15, ky+25, 10, 10, 180, 180);
		paint.fillArc(kx+25, ky+25, 10, 10, 180, 180);
		
		//paint eyes
		paint.setColor(Color.WHITE);
		
			paint.fillOval(kx+8, ky+10, 10, 20);
			paint.fillOval(kx+22, ky+10, 10, 20);
			
			paint.setColor(Color.black);
			
			paint.fillOval(kx+11, ky+13, 5, 10);
			paint.fillOval(kx+24, ky+13, 5, 10);
		
		}
		
	}
	
	public static void paint_Yiyun(Graphics paint,int kx, int ky, int time)
	{
		
		if(buff.getBuff())
		{
			
			
			if(time % 50 <= 25)
			paint.setColor(new Color(102,0,153));
			else
			paint.setColor(Color.PINK);
			
			
			
			//head
			paint.fillArc(kx+5, ky+5, 30, 20,0,180);
			//body
			paint.fillRect(kx+5, ky+15, 30, 15);
			//foots
			paint.fillArc(kx+5, ky+25, 10, 10, 180, 180);
			paint.fillArc(kx+15, ky+25, 10, 10, 180, 180);
			paint.fillArc(kx+25, ky+25, 10, 10, 180, 180);
			//eyes
			paint.setColor(Color.YELLOW);
			
			paint.drawLine(kx+10, ky+12,kx+14, ky+18);
			paint.drawLine(kx+14, ky+12,kx+10, ky+18);
			
			paint.drawLine(kx+26, ky+12,kx+30, ky+18);
			paint.drawLine(kx+30, ky+12,kx+26, ky+18);
			
			//mouse
			paint.drawLine(kx+8, ky+28,kx+11, ky+23);
			paint.drawLine(kx+11, ky+23,kx+14, ky+28);
			paint.drawLine(kx+14, ky+28,kx+17, ky+23);
			paint.drawLine(kx+17, ky+23,kx+20, ky+28);
			paint.drawLine(kx+20, ky+28,kx+23, ky+23);
			paint.drawLine(kx+23, ky+23,kx+26, ky+28);
			paint.drawLine(kx+26, ky+28,kx+29, ky+23);
			paint.drawLine(kx+29, ky+23,kx+32, ky+28);
			
		}
		
		else
		{
		
		
		
		
		paint.setColor(Color.pink);
		//paint.setColor(Color.pink);
		
		
		//head
				paint.fillArc(kx+5, ky+5, 30, 20,0,180);
				//body
				paint.fillRect(kx+5, ky+15, 30, 15);
				//foots
				paint.fillArc(kx+5, ky+25, 10, 10, 180, 180);
				paint.fillArc(kx+15, ky+25, 10, 10, 180, 180);
				paint.fillArc(kx+25, ky+25, 10, 10, 180, 180);
				
				//paint eyes
				paint.setColor(Color.WHITE);

					paint.fillOval(kx+8, ky+10, 10, 20);
					paint.fillOval(kx+22, ky+10, 10, 20);
					
					paint.setColor(Color.black);
					
					paint.fillOval(kx+11, ky+13, 5, 10);
					paint.fillOval(kx+24, ky+13, 5, 10);
		}

	}

	
	public static void paint_Guizhen(Graphics paint,int kx, int ky, int kvx, int kvy, int time)
	{
		if(buff.getBuff())
		{
			
			if(time % 50 <= 25)
			paint.setColor(new Color(102,0,153));
			else
			paint.setColor(Color.red);
			
			
			
			//head
			paint.fillArc(kx+5, ky+5, 30, 20,0,180);
			//body
			paint.fillRect(kx+5, ky+15, 30, 15);
			//foots
			paint.fillArc(kx+5, ky+25, 10, 10, 180, 180);
			paint.fillArc(kx+15, ky+25, 10, 10, 180, 180);
			paint.fillArc(kx+25, ky+25, 10, 10, 180, 180);
			//eyes
			paint.setColor(Color.YELLOW);
			
			paint.drawLine(kx+10, ky+12,kx+14, ky+18);
			paint.drawLine(kx+14, ky+12,kx+10, ky+18);
			
			paint.drawLine(kx+26, ky+12,kx+30, ky+18);
			paint.drawLine(kx+30, ky+12,kx+26, ky+18);
			
			//mouse
			paint.drawLine(kx+8, ky+28,kx+11, ky+23);
			paint.drawLine(kx+11, ky+23,kx+14, ky+28);
			paint.drawLine(kx+14, ky+28,kx+17, ky+23);
			paint.drawLine(kx+17, ky+23,kx+20, ky+28);
			paint.drawLine(kx+20, ky+28,kx+23, ky+23);
			paint.drawLine(kx+23, ky+23,kx+26, ky+28);
			paint.drawLine(kx+26, ky+28,kx+29, ky+23);
			paint.drawLine(kx+29, ky+23,kx+32, ky+28);
			
		}
		
		else
		{	
		
		paint.setColor(Color.red);
				//paint.setColor(Color.pink);
		
		
				//head
				paint.fillArc(kx+5, ky+5, 30, 20,0,180);
				//body
				paint.fillRect(kx+5, ky+15, 30, 15);
				//foots
				paint.fillArc(kx+5, ky+25, 10, 10, 180, 180);
				paint.fillArc(kx+15, ky+25, 10, 10, 180, 180);
				paint.fillArc(kx+25, ky+25, 10, 10, 180, 180);
				
				//paint eyes
				paint.setColor(Color.WHITE);
				
					paint.fillOval(kx+8, ky+10, 10, 20);
					paint.fillOval(kx+22, ky+10, 10, 20);
					
					paint.setColor(Color.black);
					
					paint.fillOval(kx+11, ky+13, 5, 10);
					paint.fillOval(kx+24, ky+13, 5, 10);
				
		}
	}
	
	public static void paint_Ian(Graphics paint,int kx, int ky, int kvx, int kvy, int time)
	{
		if(buff.getBuff())
		{
			
			if(time % 50 <= 25)
			paint.setColor(new Color(102,0,153));
			else
			paint.setColor(new Color(255,204,0));
			
			//head
			paint.fillArc(kx+5, ky+5, 30, 20,0,180);
			//body
			paint.fillRect(kx+5, ky+15, 30, 15);
			//foots
			paint.fillArc(kx+5, ky+25, 10, 10, 180, 180);
			paint.fillArc(kx+15, ky+25, 10, 10, 180, 180);
			paint.fillArc(kx+25, ky+25, 10, 10, 180, 180);
			//eyes
			paint.setColor(Color.YELLOW);
			
			paint.drawLine(kx+10, ky+12,kx+14, ky+18);
			paint.drawLine(kx+14, ky+12,kx+10, ky+18);
			
			paint.drawLine(kx+26, ky+12,kx+30, ky+18);
			paint.drawLine(kx+30, ky+12,kx+26, ky+18);
			
			//mouse
			paint.drawLine(kx+8, ky+28,kx+11, ky+23);
			paint.drawLine(kx+11, ky+23,kx+14, ky+28);
			paint.drawLine(kx+14, ky+28,kx+17, ky+23);
			paint.drawLine(kx+17, ky+23,kx+20, ky+28);
			paint.drawLine(kx+20, ky+28,kx+23, ky+23);
			paint.drawLine(kx+23, ky+23,kx+26, ky+28);
			paint.drawLine(kx+26, ky+28,kx+29, ky+23);
			paint.drawLine(kx+29, ky+23,kx+32, ky+28);
			
		}
		
		else
		{	
				//set main color
				paint.setColor(new Color(255,204,0));
		
		
				//head
				paint.fillArc(kx+5, ky+5, 30, 20,0,180);
				//body
				paint.fillRect(kx+5, ky+15, 30, 15);
				//foots
				paint.fillArc(kx+5, ky+25, 10, 10, 180, 180);
				paint.fillArc(kx+15, ky+25, 10, 10, 180, 180);
				paint.fillArc(kx+25, ky+25, 10, 10, 180, 180);
				
				//paint eyes
				paint.setColor(Color.WHITE);
				
					paint.fillOval(kx+8, ky+10, 10, 20);
					paint.fillOval(kx+22, ky+10, 10, 20);
					
					paint.setColor(Color.black);
					
					paint.fillOval(kx+11, ky+13, 5, 10);
					paint.fillOval(kx+24, ky+13, 5, 10);
				
		}
	}

	public static void BuffBar(Graphics paint) {
		
		paint.setColor(Color.BLUE);
		paint.fillRect(310, 700, 210, 40);
		
		paint.setColor(Color.black);
		paint.fillRect(315, 705, 200, 30);
		
		if(buff.getTime() >= 70)
		{paint.setColor(Color.green);
		}
		else if (buff.getTime() >= 30)
		{
			paint.setColor(Color.ORANGE);
		}
		else 
		{
			paint.setColor(Color.red);
		}
		
		paint.fillRect(315, 705, buff.getTime()*2, 30);
		
		paint.setColor(Color.white);
		paint.setFont(newFont);
		paint.drawString("Buff", 230, 735);
		
		
	}
	
	public static void startCount(Graphics paint, int time)
	
	{	String jb1 = "1";
		String jb2 = "2";
		String jb3 = "3";
		String jbgo = "GO!!!";
		
		Font ft = new Font("Comic Sans MS",Font.BOLD,200);
		
		paint.setColor(Color.red);
		
		paint.setFont(ft);
		
		if(time >200 &&time <= 400)
		
			paint.drawString(jb3, 320, 400);
		
		else if(time >400 && time <= 600)
			
			paint.drawString(jb2, 320, 400);
		
		else if (time >600 && time <= 800)
			
			paint.drawString(jb1, 320, 400);
		
		else if (time >800 && time <= 1000)
			
			paint.drawString(jbgo, 200, 400);
		
	}
	
	public static void CountLife(Graphics paint,int life) 
	{	
		
		//set color
		paint.setColor(Color.yellow);
				
		// drawing face
				
				
		paint.fillArc(50, 700, 40, 40,15, 165);
		paint.fillArc(50, 700, 40, 40,180, 155);
				
		
				
		//drawing eyes
		paint.setColor(Color.BLACK);
		paint.fillOval(65, 705, 6, 6);
		
		
		
		paint.setColor(Color.white);
		paint.setFont(newFont);
		paint.drawString("X  ", 110, 735);
		
		paint.setColor(Color.RED);
		paint.setFont(new Font("Comic Sans MS",Font.BOLD,50));
		paint.drawString(""+life , 150, 740);
	}
	
	public static void winAnimation(Graphics Graph, int score,int time) 
	{
		
		Graph.setColor(Color.RED);
		Graph.setFont(new Font("Comic Sans MS",Font.BOLD,100));
		Graph.drawString("Score: "+score , 80, 500);
		
		if(MoveRight)
		{
		board_paint.paint_right_face(Graph, loseX, 650, time);
		
		board_paint.paint_Guizhen(Graph, loseX-100, 650, 1, 0, time);
		
		board_paint.paint_Yiyun(Graph, loseX-150, 650, time);
		
		board_paint.paint_david(Graph, loseX-200, 650, "RIGHT", time);
		
		board_paint.paint_Ian(Graph, loseX-250, 650, 1, 0, time);
		
		board_paint.paint_kerry(Graph, loseX-300, 650,"RIGHT", time);
		
		if(time % 3 == 0)
		loseX++;
		}
		
		else
		{
			board_paint.paint_left_face(Graph, loseX, 650, time);
			
			board_paint.paint_Guizhen(Graph, loseX+100, 650, -1, 0, time);
			
			board_paint.paint_Yiyun(Graph, loseX+150, 650, time);
			
			board_paint.paint_david(Graph, loseX+200, 650, "LEFT", time);
			
			board_paint.paint_Ian(Graph, loseX+250, 650, -1, 0, time);
			
			board_paint.paint_kerry(Graph, loseX+300, 650,"LEFT", time);
			
			if(time % 3 == 0)
			loseX--;
		}
		
		if(loseX >= 1100)
		{
			loseX = 800;
			MoveRight = false;
		}
		
		else if (loseX <= -400)
		{
			loseX = -40;
			MoveRight = true;
		}
		
	}
	
	public static void loseAnimation(Graphics Graph, int score,int time) 
	{
		buff.TurnOn();
		
		Graph.setColor(Color.RED);
		Graph.setFont(new Font("Comic Sans MS",Font.BOLD,100));
		Graph.drawString("Score: "+score , 80, 500);
		
		if(MoveRight)
		{	board_paint.paint_right_face(Graph, winX, 650, time);
			
			board_paint.paint_Guizhen(Graph, winX+100, 650, -1, 0, time);
			
			board_paint.paint_Yiyun(Graph, winX+150, 650, time);
			
			board_paint.paint_david(Graph, winX+200, 650, "LEFT", time);
			
			board_paint.paint_Ian(Graph, winX+250, 650, -1, 0, time);
			
			board_paint.paint_kerry(Graph, winX+300, 650,"LEFT", time);
		
			if(time % 3 == 0)
			winX++;
		}
		
		else
		{
			board_paint.paint_left_face(Graph, winX, 650, time);
		
			board_paint.paint_Guizhen(Graph, winX-100, 650, 1, 0, time);
		
			board_paint.paint_Yiyun(Graph, winX-150, 650, time);
		
			board_paint.paint_david(Graph, winX-200, 650, "RIGHT", time);
		
			board_paint.paint_Ian(Graph, winX-250, 650, 1, 0, time);
		
			board_paint.paint_kerry(Graph, winX-300, 650,"RIGHT", time);
			
			if(time % 3 == 0)
			winX--;
		}
		
		if(winX >= 1200)
		{
			winX = 1100;
			MoveRight = false;
		}
		
		else if (winX <= -500)
		{
			winX = -400;
			MoveRight = true;
		}
		
		
		
	}

	
}
