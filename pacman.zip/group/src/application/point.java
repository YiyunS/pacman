package application;

public class point {
	
	private int x;
	
	private int y;

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public void setX(int ax) {
		this.x = ax;
	}

	public void setY(int ay) {
		this.y = ay;
	}
	
	public point(int ax, int ay) 
	{
		this.setX(ax);
		this.setY(ay);
	}
	
	public static point[][] pointArr(int[][] input)
	{
		point[][] resualt = new point[input.length][input[0].length];
		for (int i = 0; i< input.length; i ++)
			for (int j = 0 ; j < input[0].length; j ++)
			{
				resualt[i][j] = new point(i,j);
			}
		return resualt;
	}
	

	

}
