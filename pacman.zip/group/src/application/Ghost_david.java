package application;

import java.util.LinkedList;
import java.util.List;

public class Ghost_david {
	
	//David's instances
		 
		 boolean incage = true; 
		 
		 int dx = 100;
		 
		 int dy = 200;
		 
		 String Dface = null;
		 
		 int dvx = 0;
		 
		 int dvy = 0;
		 
		 int Ddirection;
		 
		 int dcount = 0; 
		 
		 public static boolean getCaught = false;
		 
		 
			public void DavidMove()
			{
				if(getCaught)
				{
					this.freeze();
				}
					
				else
				{
//					if(buff.getBuff() && !incage)
//					{
//						this.deBuffMove();
//					}
//					else
//					{
						this.normalMove();
					}
				//}
					
			}
			private void eat_beans()
			{	
				//EAT right BEANS
				if ((board.arr[(dx+17) / 40][(dy ) / 40] ==  1) && ((dx+17) % 40 == 0) && (dy % 40 == 0))
				{
					
					board.arr[(dx+17) / 40][(dy ) / 40] = 0;
					board.Dot--;
					GameSound.playSound(GameSound.edot);
				}
				//EAT left BEANS
				else if ((board.arr[(dx-17) / 40][(dy ) / 40] ==  1) && ((dx-17) % 40 == 0) && (dy % 40 == 0))
				{
					
					board.arr[(dx-17) / 40][(dy ) / 40] = 0;
					board.Dot--;
					GameSound.playSound(GameSound.edot);
				}
				
				//EAT down BEANS
				else if ((board.arr[(dx) / 40][(dy +17) / 40] ==  1) && (dx % 40 == 0) && ((dy+17) % 40 == 0))
				{
							
					board.arr[(dx) / 40][(dy+17 ) / 40] = 0;
					board.Dot--;
					GameSound.playSound(GameSound.edot);
				}
				
				//EAT up BEANS
				else if ((board.arr[(dx) / 40][(dy -17) / 40] ==  1) && (dx % 40 == 0) && ((dy-17) % 40 == 0))
				{
									
					board.arr[(dx) / 40][(dy-17 ) / 40] = 0;
					board.Dot--;
					GameSound.playSound(GameSound.edot);
				}
				
						
				//EAT right BEANS
				if ((board.arr[(dx+17) / 40][(dy ) / 40] ==  4) && ((dx+17) % 40 == 0) && (dy % 40 == 0))
				{
					board.arr[(dx+17) / 40][(dy ) / 40] = 0;
					buff.TurnOn();
					GameSound.playSound(GameSound.eheart);
				}
				//EAT left BEANS
				else if ((board.arr[(dx-17) / 40][(dy ) / 40] ==  4) && ((dx-17) % 40 == 0) && (dy % 40 == 0))
				{
					board.arr[(dx-17) / 40][(dy ) / 40] = 0;
					buff.TurnOn();
					GameSound.playSound(GameSound.eheart);
				}
					//EAT down BEANS
					else if ((board.arr[(dx) / 40][(dy +17) / 40] ==  4) && (dx % 40 == 0) && ((dy+17) % 40 == 0))
				{
						board.arr[(dx) / 40][(dy+17 ) / 40] = 0;
						buff.TurnOn();
						GameSound.playSound(GameSound.eheart);
				}
					//EAT up BEANS
					else if ((board.arr[(dx) / 40][(dy -17) / 40] ==  4) && (dx % 40 == 0) && ((dy-17) % 40 == 0))
				{
						board.arr[(dx) / 40][(dy-17 ) / 40] = 0;
						buff.TurnOn();
						GameSound.playSound(GameSound.eheart);
				}	
			}
		public void normalMove() 
		{	
			

			List<String> possible_move = new LinkedList<>();
			
			this.eat_beans();
			
			if (dy % 40 == 0 && map.beanMtx[dx/40 +1][dy/40] != 3 && map.beanMtx[dx/40 +1][dy/40] != 2 && dvx != -1)
			{
				possible_move.add("RIGHT");
			}
			
			if (dx % 40 == 0 && map.beanMtx[dx/40][dy/40 + 1] != 3 && map.beanMtx[dx / 40][dy / 40 + 1] != 2 && dvy != -1)
			{
				possible_move.add("DOWN");
			}
			
			if (dy % 40 == 0 && map.beanMtx[dx/40 - 1][dy/40] != 3 && map.beanMtx[dx / 40 - 1][dy / 40] != 2 && dvx != 1)
			{
				possible_move.add("LEFT");
			}
			
			if (dx % 40 == 0 && map.beanMtx[dx / 40][dy / 40 - 1] != 3 && map.beanMtx[dx / 40][dy / 40 - 1] != 2 && dvy != 1)
			{
				
				possible_move.add("UP");
			}
			
		
			if (possible_move.isEmpty())
				possible_move.add("No Way");
			
			
			
			Ddirection = Movement.generateRandInt(0,possible_move.size()-1);
			
			
			String choose = possible_move.get(Ddirection);
			
			
			Dface = choose;
			
			if (choose == "RIGHT" )
			{
				dvx = 1;
				dvy = 0;
				
			
				
				//System.out.println("111111111");
			}
			
			else if (choose == "DOWN" )
			{
				dvx = 0;
				dvy = 1;
				
				//System.out.println("2222222222");
			}
			else if (choose == "LEFT" )
			{
				dvx = -1;
				dvy = 0;
				//System.out.println("33333");
				
			}
			else if (choose == "UP" )
			{
				dvx = 0;
				dvy = -1;
				
				//System.out.println("4444444");
			}
			
			else if (choose == "No Way" && dx % 40 == 0 && dy % 40 == 0)
			{
				dvx *= -1;
				dvy *= -1;
				
			}	
			
			if (dcount % 2 == 0 || dcount % 3 == 0  )
			{dx+=dvx;
			dy+=dvy;}
			
			dcount+=1;

		}
		
		//Delete
		private void getOutCage() {
			
			dvx = 1;
			dvy = 0;
			Dface = "RIGHT";
			
			if(dx == 360)
			{
				dvx = 0;
				dvy = 1;
				Dface = "DOWN";
			}
			
			if(dcount % 2 ==0)
			
			{dx+=dvx;
			
			dy+=dvy;}
			
			if( dx == 360 && dy == 280)
			{
				incage = false;
			}
			
			dcount++;
		}
		
		private void deBuffMove() 
		{	
			

			List<String> possible_move = new LinkedList<>();
			
			
			
			if (dy % 40 == 0 && map.beanMtx[dx/40 +1][dy/40] != 3 && map.beanMtx[dx/40 +1][dy/40] != 2 && dvx != -1)
			{
				possible_move.add("RIGHT");
			}
			
			if (dx % 40 == 0 && map.beanMtx[dx/40][dy/40 + 1] != 3 && map.beanMtx[dx / 40][dy / 40 + 1] != 2 && dvy != -1)
			{
				possible_move.add("DOWN");
			}
			
			if (dy % 40 == 0 && map.beanMtx[dx/40 - 1][dy/40] != 3 && map.beanMtx[dx / 40 - 1][dy / 40] != 2 && dvx != 1)
			{
				possible_move.add("LEFT");
			}
			
			if (dx % 40 == 0 && map.beanMtx[dx / 40][dy / 40 - 1] != 3 && map.beanMtx[dx / 40][dy / 40 - 1] != 2 && dvy != 1)
			{
				
				possible_move.add("UP");
			}
			
		
			if (possible_move.isEmpty())
				possible_move.add("No Way");
			
			
			
			Ddirection = Movement.generateRandInt(0,possible_move.size()-1);
			
			
			String choose = possible_move.get(Ddirection);
			
			
			Dface = choose;
			
			if (choose == "RIGHT" )
			{
				dvx = 1;
				dvy = 0;
				
			
				
				//System.out.println("111111111");
			}
			
			else if (choose == "DOWN" )
			{
				dvx = 0;
				dvy = 1;
				
				//System.out.println("2222222222");
			}
			else if (choose == "LEFT" )
			{
				dvx = -1;
				dvy = 0;
				//System.out.println("33333");
				
			}
			else if (choose == "UP" )
			{
				dvx = 0;
				dvy = -1;
				
				//System.out.println("4444444");
			}
			
			else if (choose == "No Way" && dx % 40 == 0 && dy % 40 == 0)
			{
				dvx *= -1;
				dvy *= -1;
				
			}	
			
			if (dcount % 8 == 0)
			{dx+=dvx;
			dy+=dvy;}
			
			dcount+=1;

		}
		
		 public void freeze()
			{
				dvx = 0;
				dvy = 0;
				
				dx += dvx;
				dy += dvy;
			}
		
		

}
