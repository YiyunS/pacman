

package application;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import java.util.Scanner;

import javax.swing.Timer;


import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;


@SuppressWarnings("serial")
public class board extends JPanel implements ActionListener,KeyListener{
	
	
	JButton Button = new JButton("Play Again");
	
	 
	
	PacMan pac = new PacMan();
	PacMan pac2 = new PacMan();
	
	static point end = Movement.selectPoint(PacMan.px, PacMan.py);
	
	
	public static boolean KerryRun = true;
	
	public static boolean DavidRun = true;
	
	public static boolean IanRun = false;
	
	public static boolean GuizhenRun = true;
	
	public static boolean YiyunRun = true;
	
	Ghost_kerry kerry = new Ghost_kerry();

	Ghost_david david = new Ghost_david();
	
	Ghost_guizhen guizhen = new Ghost_guizhen();
	
	Ghost_yiyun yiyun = new Ghost_yiyun();
	
	Ghost_Ian ian = new Ghost_Ian();
	
	private Timer t;
	
	
	public static boolean Started = false;
	//map arr
	static int[][] arr = map.reset();
	
	buff DotBuff = new buff();
	
	public static int Count_time = 0;
	
	public static int Point = 0;
	
	public static int Dot = 142; //142
	
	public static int defaultLife = 3;
	
	private int life = defaultLife;

	private boolean gameRun = true;
	
	
	
public board()
	{	
		
		t =  new Timer(7,this);
		t.start();
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		
		Button.setVisible(false);
		Button.addActionListener(this);
		add(Button);
		
	}
public void paintComponent(Graphics Graph)
	{
		board_paint.setButton(Button);
		
	
		if(life > 0 && Dot > 0)
		{
		
		//painting background
		Graph.setColor(Color.BLACK);
		Graph.fillRect(0,0,this.getWidth(),this.getHeight());
		
		// drawing beans
		board_paint.paint_beans(Graph, arr);
		
		//drawing big beans
		board_paint.paint_big_beans(Graph, arr, Count_time);
		
		//drawing inner walls
		board_paint.paint_inner_wall(Graph, arr);
		//drawing pacman at the beginning
		
		if  (!Started)
		{
			board_paint.paint_normal_face(Graph, PacMan.px, PacMan.py);
		}
		else {
			board_paint.paint_pac(Graph, pac.px, pac.py, pac.pvx, pac.pvy, pac.face_to, Count_time);
		}
		
		
		if(KerryRun)
		board_paint.paint_kerry(Graph,kerry.kx,kerry.ky,kerry.Kface,Count_time);
		
		if(DavidRun)
		board_paint.paint_david(Graph, david.dx, david.dy, david.Dface, Count_time);
		
		if(GuizhenRun)
		board_paint.paint_Guizhen(Graph, guizhen.gx, guizhen.gy, guizhen.gvx, guizhen.gvy, Count_time);
		
		if(YiyunRun)
		board_paint.paint_Yiyun(Graph, yiyun.yx, yiyun.yy,Count_time);
		
		if(IanRun)
		board_paint.paint_Ian(Graph, ian.ix, ian.iy, ian.ivx, ian.ivy, Count_time);
		
		//drawing surrounding walls
		board_paint.paint_sur_wall(Graph);
		
		board_paint.CountLife(Graph, life);
		
		board_paint.BuffBar(Graph);
		
		
		board_paint.Count_Points(Graph, Point);
		
		board_paint.startCount(Graph,  Count_time);
		}
		
		else if (life <= 0)
		{
			ImageIcon image = new ImageIcon(getClass().getResource("ulost.png"));
			Image img = image.getImage();
			Graph.drawImage(img, 0, 0, this.getWidth(),this.getHeight(), this);
			
			board_paint.winAnimation(Graph,Point, Count_time);
		}
		
		else if(Dot <= 0)
		{
			ImageIcon image = new ImageIcon(getClass().getResource("uwon.png"));
			Image img = image.getImage();
			Graph.drawImage(img, 0, 0, this.getWidth(),this.getHeight(), this);
			
			board_paint.loseAnimation(Graph, Point, Count_time);
		}
	}	

	//listen key inputs
	public void keyPressed(KeyEvent event)
	{
		 int c = event.getKeyCode(); 
		 
		 	if (c == KeyEvent.VK_UP)
			{	
		 		pac.press = 20;
		 		Started = true;
		 		t.start();
		 		pac.face_to = "UP";
			}
    
			if (c == KeyEvent.VK_DOWN)
			{	
				pac.press = 20;
				Started = true;
				t.start();
				pac.face_to = "DOWN";	
			}
			
			if (c == KeyEvent.VK_LEFT)
			{	
				pac.press = 20;
				Started = true;
				t.start();
				pac.face_to = "LEFT";
			}
   
			if (c == KeyEvent.VK_RIGHT)
				
			{	
				pac.press = 20;
				Started = true;
				t.start();
				pac.face_to = "RIGHT";
			}
			if (c == KeyEvent.VK_W)
			{	
		 		Started = true;
		 		t.start();
		 		pac2.face_to = "UP";
			}
    
			if (c == KeyEvent.VK_S)
			{	
				Started = true;
				t.start();
				pac2.face_to = "DOWN";	
			}
			
			if (c == KeyEvent.VK_A)
			{	
				
				Started = true;
				t.start();
				pac2.face_to = "LEFT";
			}
   
			if (c == KeyEvent.VK_D)
				
			{	
				Started = true;
				t.start();
				pac2.face_to = "RIGHT";
			}
			
			if(c == KeyEvent.VK_SPACE)
				{
				
				t.stop();
				}
			
	}	
	

	@Override
	public void actionPerformed(ActionEvent event) {
		
		if(Count_time == 200 && life > 0 && Dot > 0)
		{
			GameSound.playSound(GameSound.begin);
		}
		
		if(event.getSource() == Button)
		{	
			this.reset();
		}

		
		if(Dot <= 0 || life <= 0)
		{	
			Button.setVisible(true);
		}
		
		if(life > 0 && Dot > 0)
		{
			this.reserrect();
			this.StartMove();
		}
		
		this.gameEnd();
		
		Count_time++;
		
		repaint();
	
		
	}
	

	
	private void StartMove()
	{
		if(Count_time > 800)
		{
		pac.PacMove();
		
		this.catchPac();
		
		if(IanRun)
		ian.ianMove();
		
		if(KerryRun)
		kerry.KerryMove();
		
		if(DavidRun)
		david.DavidMove();
		
		if(GuizhenRun)
		guizhen.GuizhenMove();
		
		if(YiyunRun)
		yiyun.YiyunMove();
		
		
		
		if(Count_time % 10 == 0)
		{
			DotBuff.buffRun();
		}
		
		}
	}
		
	
	private void catchPac() {
		
		if(    (   (Movement.getCaught(david.dx, david.dy, PacMan.px, PacMan.py)) 
				|| (Movement.getCaught(kerry.kx, kerry.ky, PacMan.px, PacMan.py)) 
				|| (Movement.getCaught(yiyun.yx, yiyun.yy, PacMan.px, PacMan.py))
				|| (Movement.getCaught(guizhen.gx, guizhen.gy, PacMan.px, PacMan.py))
				|| (Movement.getCaught(ian.ix, ian.iy, PacMan.px, PacMan.py))
			  ) && (!buff.getBuff())
		 )
				
		{	life--;
			Count_time = 0;
			
			if(life > 0)
			GameSound.playSound(GameSound.death);
		}
		
		else if( (Movement.getCaught(yiyun.yx, yiyun.yy, PacMan.px, PacMan.py)) && (buff.getBuff()) )
		{
			yiyun.yx = 600;
			yiyun.yy = 200;
			yiyun.incage = true;
			yiyun.ycount = 0;
			yiyun.Yface = null;
			yiyun.yvx = 0;
			yiyun.yvy = 0;
			Ghost_yiyun.getCaught = true;
			
			GameSound.playSound(GameSound.eghost);

			Point+=100;
		}
		
		else if ((Movement.getCaught(guizhen.gx, guizhen.gy, PacMan.px, PacMan.py)) && (buff.getBuff()) )
		{
			guizhen.gx = 480;
			guizhen.gy = 200;
			guizhen.incage = true;
			guizhen.gcount = 0;
			guizhen.gface = null;
			guizhen.gvx = 0;
			guizhen.gvy = 0;
			Ghost_guizhen.getCaught =true;

			GameSound.playSound(GameSound.eghost);
			
			Point += 100;
		}
		
		else if ((Movement.getCaught(ian.ix, ian.iy, PacMan.px, PacMan.py)) && (buff.getBuff()) )
		{
			ian.ix = 360;
			ian.iy = 200;
			ian.incage = true;
			ian.icount = 0;
			ian.Iface = null;
			ian.ivx = 0;
			ian.ivy = 0;
			Ghost_Ian.getCaught = true;

			GameSound.playSound(GameSound.eghost);
			
			Point += 100;
		}
		
		else if ((Movement.getCaught(david.dx, david.dy, PacMan.px, PacMan.py))  && (buff.getBuff()) )
		{
			david.dx = 100;
			david.dy = 200;
			david.incage = true;
			david.dcount = 0;
			david.Dface = null;
			Ghost_david.getCaught = true;

			GameSound.playSound(GameSound.eghost);
			
			Point += 100;
		}
		else if (  (Movement.getCaught(kerry.kx, kerry.ky, PacMan.px, PacMan.py))   && (buff.getBuff()) )
		{
			kerry.kx = 240;
			kerry.ky = 200;
			kerry.incage = true;
			kerry.kcount = 0;
			kerry.Kface = null;
			Ghost_kerry.getCaught = true;

			GameSound.playSound(GameSound.eghost);
			
			Point += 100;
		}
		
		
		
	}
	
	private void reserrect()
	{	
		
		if(Count_time >= 200 && Count_time <= 800 )
		{
			
			PacMan.px = 360;
			PacMan.py = 560;
			Started = false;
			
			Ghost_Ian.getCaught = false;
	
			Ghost_guizhen.getCaught = false;
			
			Ghost_yiyun.getCaught = false;
			
			Ghost_kerry.getCaught = false;
			
			Ghost_david.getCaught = false;

		
		}
	}
	
	private void reset()
	{
		PacMan.px = 360;
		PacMan.py = 560;
		
		ian.ix = 360;
		ian.iy = 200;
		ian.incage = true;
		ian.icount = 0;
		ian.Iface = null;
		ian.ivx = 0;
		ian.ivy = 0;
		Ghost_Ian.getCaught = false;

		guizhen.gx = 480;
		guizhen.gy = 200;
		guizhen.incage = true;
		guizhen.gcount = 0;
		guizhen.gface = null;
		guizhen.gvx = 0;
		guizhen.gvy = 0;
		Ghost_guizhen.getCaught = false;
		
		yiyun.yx = 600;
		yiyun.yy = 200;
		yiyun.incage = true;
		yiyun.ycount = 0;
		yiyun.Yface = null;
		yiyun.yvx = 0;
		yiyun.yvy = 0;
		Ghost_yiyun.getCaught = false;
		
		kerry.kx = 240;
		kerry.ky = 200;
		kerry.incage = true;
		kerry.kcount = 0;
		kerry.Kface = null;
		Ghost_kerry.getCaught = false;
		
		david.dx = 100;
		david.dy = 200;
		david.incage = true;
		david.dcount = 0;
		david.Dface = null;
		Ghost_david.getCaught = false;
		gameRun = true;
		
		
		board_paint.loseX = -40; 
		board_paint.winX = -400;
		board_paint.MoveRight = true;
		
		
		Started = false;
		arr = map.reset();
		DotBuff = new buff();
		Count_time = 0;
		Point = 0;
		Dot = 142;
		life = defaultLife;
		buff.TurnOff();
		Button.setVisible(false);
	}
	
	private void gameEnd() 
	{
		if (gameRun && Dot <= 0 )
		{
			
			GameSound.playSound(GameSound.win);
			gameRun = false;
		}
		else if (gameRun && life <= 0 )
		{
			GameSound.playSound(GameSound.lose);
			gameRun = false;
		}
		
	}
	
	
	 
		
		
	public void askPrint() 
	{
	 
		System.out.print("Input any thing to print out the text-form: ");
		//Ask user to guess a number between 1 to 20. 
		
		Scanner scan = new Scanner(System.in); 
		scan.nextLine();
		
		this.printText();

		
	}
	
	private void printText() {
		
		for (int col = 0; col <arr[0].length; col ++)
		{
			for (int row = 0; row <arr.length; row ++)
			{ System.out.print(arr[row][col] + "   ");}
			System.out.println();
			System.out.println();
		}
		System.out.println("******************************************************************************************");
		
	}
	
	

	
	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
