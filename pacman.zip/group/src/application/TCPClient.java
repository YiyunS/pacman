package application;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Arrays;
class TCPClient {

    public static void main(String args[]) throws Exception
    {
        if (args.length != 2)
        {
            System.out.println("Usage: TCPClient <Server IP> <Server Port>");
            System.exit(1);
        }

        // Initialize a client socket connection to the server
        Socket clientSocket = new Socket(args[0], Integer.parseInt(args[1]));

        // Initialize input and an output stream for the connection(s)
        PrintWriter outBuffer =
        		new PrintWriter(clientSocket.getOutputStream(), true);

        InputStream in = clientSocket.getInputStream();
        BufferedReader inBuffer =
          new BufferedReader(new
          InputStreamReader(in));

        // Initialize user input stream
        String line;
        BufferedReader inFromUser =
        new BufferedReader(new InputStreamReader(System.in));

        // Get user input and send to the server
        // Display the echo meesage from the server
        System.out.print("Please enter a message to be sent to the server ('logout' to terminate): ");
        line = inFromUser.readLine();
        while (!line.equals("logout"))
        {
            // Send to the server
         outBuffer.println(line);

            String[] getFile = line.split(" ");
            /*if(getFile[0].equals("get")){
                FileOutputStream writer = new FileOutputStream("text.txt");
                int c = 0;
                byte[] output = new byte[0];
                byte[] bf = new byte[1];

                while((c = in.read(bf))>0){
                  output = putTogether(output,Arrays.copyOfRange(bf,0,c));
                }
                writer.write(output,0,output.length);
                writer.close();
                in.close();
            }else{
*/
            while(!inBuffer.ready()){}
            // Getting response from the server
            ArrayList<String> info = new ArrayList<String>();
            while(inBuffer.ready()){
                info.add(inBuffer.readLine());
            }
            System.out.println("Server: ");
            for(String s:info){
              if (!s.equals("list"))
              System.out.println(s);
            }
        //  }

            System.out.print("Please enter a message to be sent to the server ('logout' to terminate): ");
            line = inFromUser.readLine();
        }

        // Close the socket
        clientSocket.close();
    }

    public static byte[] putTogether(byte[] a1, byte[] a2){
      byte[] combine = new byte[a1.length + a2.length];
      System.arraycopy(a1,0,combine,0,a1.length);
      System.arraycopy(a2,0,combine,a1.length,a2.length);
      return combine;
    }
}
