package application;

import java.util.LinkedList;
import java.util.List;

public class Ghost_guizhen {
	
	boolean incage = true;
	
	 int gx = 480;
	 
	 int gy = 200;
	 
	 String gface = null;
	 
	 int gvx = 0;
	 
	 int gvy = 0;
	 
	 int Gdirection;
	 
	 int gcount = 0; 
	 
	 int lastgx = 0;
	 
	 int lastgy = 0;
	 
	 boolean bad_move =false;
	 
	 point start = Movement.selectPoint(gx, gy);
	 
	 public static boolean getCaught = false;
	 
	 public void GuizhenMove() 
	 {
		 if(getCaught)
		 {
			 this.freeze();
		 }
		 
		 else 
		 {
		 	if(buff.getBuff() && !incage)
		 	{
		 		this.deBuffMove();
		 	}
		 	else 
		 	{
		 		if (incage)
		 		{
		 			this.getOutCage();
		 		}
			
		 		else
		 		{
		 			this.normalMove();
		 		}
		 	}
		 }
	}
		
	 
	 private void normalMove()
	 {
		 if (Math.abs(PacMan.px - gx) >= 200 || Math.abs(PacMan.py-gy)>= 200)
		 {
			 this.GuizhenFarMove();
		 }
		 else 
		 {
			 this.GuizhenCloseMove();
		 }
		 
		 
	 }
	 
	 private void GuizhenFarMove()
	 {
		 List<String> possible_move = new LinkedList<>();
			
			
			
			if (gy % 40 == 0 && map.beanMtx[gx/40 +1][gy/40] != 3 && map.beanMtx[gx/40 +1][gy/40] != 2 && gvx != -1)
			{
				possible_move.add("RIGHT");
			}
			
			if (gx % 40 == 0 && map.beanMtx[gx/40][gy/40 + 1] != 3 && map.beanMtx[gx / 40][gy / 40 + 1] != 2 && gvy != -1)
			{
				possible_move.add("DOWN");
			}
			
			if (gy % 40 == 0 && map.beanMtx[gx/40 - 1][gy/40] != 3 && map.beanMtx[gx / 40 - 1][gy / 40] != 2 && gvx != 1)
			{
				possible_move.add("LEFT");
			}
			
			if (gx % 40 == 0 && map.beanMtx[gx / 40][gy / 40 - 1] != 3 && map.beanMtx[gx / 40][gy / 40 - 1] != 2 && gvy != 1)
			{
				
				possible_move.add("UP");
			}
			
		
			if (possible_move.isEmpty())
				possible_move.add("No Way");
			
			
			
			Gdirection = Movement.generateRandInt(0,possible_move.size()-1);
			
			
			String choose = possible_move.get(Gdirection);
			
			
			if (choose == "RIGHT" )
			{
				gvx = 1;
				gvy = 0;
				
			
				
				//System.out.println("111111111");
			}
			
			else if (choose == "DOWN" )
			{
				gvx = 0;
				gvy = 1;
				
				//System.out.println("2222222222");
			}
			else if (choose == "LEFT" )
			{
				gvx = -1;
				gvy = 0;
				//System.out.println("33333");
				
			}
			else if (choose == "UP" )
			{
				gvx = 0;
				gvy = -1;
				
				//System.out.println("4444444");
			}
			
			else if (choose == "No Way" && gx % 40 == 0 && gy % 40 == 0)
			{
				gvx = 0;
				gvy = 0;
				
			}	
			
			gface = choose;
			
			 if(gcount % 4 == 0)
			 { gx+=gvx;
			 gy+=gvy;}
			
			
			gcount++;
		 
		 
		 
	 }
	 
	 private void GuizhenCloseMove()
	 {
		 {
				
				
				
			 if(bad_move)
			{
				this.GuizhenRandMove();
			}
			
			else
				this.GuizhenChaseMove();
			
			if(Movement.check_hit_wall(gx, gy, gvx, gvy) || Movement.check_hit_obstacles(board.arr, gx, gy, gface))
			{
				gvy=0;
				gvx=0;
			}
			
			
		}
	
	 }
	 
	 private void GuizhenRandMove() {
		 List<String> possible_move = new LinkedList<>();
			
			
			
			if (gy % 40 == 0 && map.beanMtx[gx/40 +1][gy/40] != 3 && map.beanMtx[gx/40 +1][gy/40] != 2 && gvx != -1)
			{
				possible_move.add("RIGHT");
			}
			
			if (gx % 40 == 0 && map.beanMtx[gx/40][gy/40 + 1] != 3 && map.beanMtx[gx / 40][gy / 40 + 1] != 2 && gvy != -1)
			{
				possible_move.add("DOWN");
			}
			
			if (gy % 40 == 0 && map.beanMtx[gx/40 - 1][gy/40] != 3 && map.beanMtx[gx / 40 - 1][gy / 40] != 2 && gvx != 1)
			{
				possible_move.add("LEFT");
			
		
			}
			
			if (gx % 40 == 0 && map.beanMtx[gx / 40][gy / 40 - 1] != 3 && map.beanMtx[gx / 40][gy / 40 - 1] != 2 && gvy != 1)
			{
				
				possible_move.add("UP");
			}
			
		
			if (possible_move.isEmpty())
				possible_move.add("No Way");
			
			
			
			Gdirection = Movement.generateRandInt(0,possible_move.size()-1);
			
			
			String choose = possible_move.get(Gdirection);
			
			
			if (choose == "RIGHT" )
			{
				gvx = 1;
				gvy = 0;
				
			
				
				//System.out.println("111111111");
			}
			
			else if (choose == "DOWN" )
			{
				gvx = 0;
				gvy = 1;
				
				//System.out.println("2222222222");
			}
			else if (choose == "LEFT" )
			{
				gvx = -1;
				gvy = 0;
				//System.out.println("33333");
				
			}
			else if (choose == "UP" )
			{
				gvx = 0;
				gvy = -1;
				
				//System.out.println("4444444");
			}
			
			else if (choose == "No Way" && gx % 40 == 0 && gy % 40 == 0)
			{
				gvx *= 0;
				gvy *= 0;
				
			}	
			
			gface = choose;
			
			
			
			if(gcount % 180 == 0  )
			{
				bad_move = false;
				gcount=0;
			}
			
			if(gcount % 2 == 0)
			{gx+=gvx;
			gy+=gvy;}
			
			gcount++;
	 }
	 
	 private void GuizhenChaseMove() {
			
			start = Movement.selectPoint(gx, gy);
			
			if(gcount % 50 == 0)
				{board.end =  Movement.selectPoint(PacMan.px, PacMan.py);}
			
			findPath fp = new findPath(board.arr, start, board.end);
			
			point[] path = fp.showPath();
			
			
			
			if(path.length >= 2)
			{
			if (gx > path[1].getX()*40 && gy % 40 ==0)
			{
				gvx = -1;
				gvy = 0;
				gface = "LEFT";
			}
			
			else if (gx < path[1].getX()*40 && gy % 40 ==0)
			{
				gvx = 1;
				gvy = 0;
				gface = "RIGHT";
			}
			
			else
			{
				gvx = 0;
			}
			
			
			
			
			if (gy > path[1].getY()*40 && gx % 40 ==0)
			{
				gvy = -1;
				gvx = 0;
				gface="UP";
			}
			
			else if (gy < path[1].getY()*40 && gx % 40 ==0)
			{
				gvy = 1;
				gvx = 0;
				gface="DOWN";
			}
			
			else
			{
				gvy = 0;
			}
			
			}
			
			else if(gx / 40 == PacMan.px/40 && gy/40 == PacMan.py/40)
			{
				
				
				if (gx > PacMan.px && gy % 40 ==0)
				{
					gvx = -1;
					gvy = 0;
					gface = "LEFT";
				}
				
				else if (gx < PacMan.px && gy % 40 ==0)
				{
					gvx = 1;
					gvy = 0;
					gface = "RIGHT";
				}
				
				
				
				
				
				
				else if (gy > PacMan.py && gx % 40 ==0)
				{
					gvy = -1;
					gvx = 0;
					gface="UP";
					
				}
				
				else if (gy < PacMan.py && gx % 40 ==0)
				{
					gvy = 1;
					gvx = 0;
					gface="DOWN";
				}
				
				else
				{
					gvy = 0;
					gvx = 0;
				}
				
		
			}
			
			if(gcount % 2 == 0)
			{gx+=gvx;
			gy+=gvy;}
			
			if(lastgx == gx && lastgy ==gy)
			{
				bad_move = true;
				gcount = 0;
				
			}
			if(gcount % 2 == 0)
			 {lastgx = gx-gvx;
			 lastgy = gy-gvy;}
			
		
			gcount++;
		
		}
	 
	 
	 private void getOutCage() {
			
			gvx = -1;
			gvy = 0;
			
			if( gx == 360)
			{
				gvx = 0;
				gvy = -1;
	
			}
			
			if(gcount>= 300 && gcount % 3 ==0)
			
			{gx+=gvx;
			
			gy+=gvy;}
			
			if( gx == 360 && gy == 120)
			{
				incage = false;
			}
			
			gcount++;
		}
	 private void deBuffMove() 
		{	
			

			List<String> possible_move = new LinkedList<>();
			
			
			
			if (gy % 40 == 0 && map.beanMtx[gx/40 +1][gy/40] != 3 && map.beanMtx[gx/40 +1][gy/40] != 2 && gvx != -1)
			{
				possible_move.add("RIGHT");
			}
			
			if (gx % 40 == 0 && map.beanMtx[gx/40][gy/40 + 1] != 3 && map.beanMtx[gx / 40][gy / 40 + 1] != 2 && gvy != -1)
			{
				possible_move.add("DOWN");
			}
			
			if (gy % 40 == 0 && map.beanMtx[gx/40 - 1][gy/40] != 3 && map.beanMtx[gx / 40 - 1][gy / 40] != 2 && gvx != 1)
			{
				possible_move.add("LEFT");
			}
			
			if (gx % 40 == 0 && map.beanMtx[gx / 40][gy / 40 - 1] != 3 && map.beanMtx[gx / 40][gy / 40 - 1] != 2 && gvy != 1)
			{
				
				possible_move.add("UP");
			}
			
		
			if (possible_move.isEmpty())
				possible_move.add("No Way");
			
			
			
			Gdirection = Movement.generateRandInt(0,possible_move.size()-1);
			
			
			String choose = possible_move.get(Gdirection);
			
			
			gface = choose;
			
			if (choose == "RIGHT" )
			{
				gvx = 1;
				gvy = 0;
				
			
				
				//System.out.println("111111111");
			}
			
			else if (choose == "DOWN" )
			{
				gvx = 0;
				gvy = 1;
				
				//System.out.println("2222222222");
			}
			else if (choose == "LEFT" )
			{
				gvx = -1;
				gvy = 0;
				//System.out.println("33333");
				
			}
			else if (choose == "UP" )
			{
				gvx = 0;
				gvy = -1;
				
				//System.out.println("4444444");
			}
			
			else if (choose == "No Way" && gx % 40 == 0 && gy % 40 == 0)
			{
				gvx *= -1;
				gvy *= -1;
				
			}	
			
			if (gcount % 8 == 0)
			{gx+=gvx;
			gy+=gvy;}
			
			gcount+=1;

		}
	 
	 public void freeze()
		{
			gvx = 0;
			gvy = 0;
			
			gx += gvx;
			gy += gvy;
		}
		
		
		


}
	 
	
	
