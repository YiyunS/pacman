package application;

import java.util.Random;

public class Movement {
	
	
	public static boolean getCaught(int ghox, int ghoy, int pacx, int pacy) {
		if (ghox == pacx && Math.abs(ghoy - pacy) <= 30)
		
			return true;
			
		else if (ghoy == pacy && Math.abs(ghox - pacx) <= 30)
			
			return true;
			
		else if (Math.abs(ghox-pacx) <= 15 && Math.abs(ghoy-pacy) <= 15)
			return true;
		else
			
			return false;
				
		}
	
	
	
	
	public static boolean check_hit_obstacles(int[][] arr, int px, int py, String face_to) 
	{
		if ( (face_to == "RIGHT") 
				&& (px % 40 == 0)  
				&& (arr[(px ) / 40+1][(py ) / 40+1] == 2)
				&& (py % 40 != 0) )
		{
			return true;
		}
		else if (  (face_to == "RIGHT") 
				&& (px % 40 == 0) 
				&& (arr[(px ) / 40+1][(py ) / 40] == 2) )
		{
			return true;
		}
		
		
		if ( (face_to == "LEFT") 
				&& (px % 40 == 0) 
				&& (arr[(px ) / 40-1][(py ) / 40+1] == 2) 
				&& (py % 40 != 0) )
		{
			return true;
		}
		else if (  (face_to == "LEFT") 
				&& (px % 40 == 0) 
				&& (arr[(px ) / 40-1][(py ) / 40] == 2) )
				
		{
			return true;
		}
		
		if ( (face_to == "UP") 
				&& (py % 40 == 0) 
				&& (arr[(px )/ 40+1][(py ) / 40-1] == 2) 
				//&& (arr[(x ) / 40][(y ) / 40-1] != 2) 
				&& (px % 40 != 0) )
		{
			return true;
		}
		else if (  (face_to == "UP") 
				&& (py % 40 == 0) 
				&& (arr[(px ) / 40][(py ) / 40 -1] == 2) )
				
		{
			return true;
		}
		if ( (face_to == "DOWN") 
				&& (py % 40 == 0) 
				&& (arr[(px )/ 40+1][(py ) / 40+1] == 2) 
				&& (px % 40 != 0) )
		{
			return true;
		}
		else if (  (face_to == "DOWN") 
				&& (py % 40 == 0) 
				&& (arr[(px ) / 40][(py ) / 40 +1] == 2) )
				
		{
			return true;
		}
		
	
		return false;
	}
	public static boolean check_hit_wall(int px, int py , int pvx, int pvy) 
	{
		
		if (px <= 40 && pvx < 0) // hit left wall
			return true;
		else if (px >= 680 && pvx > 0) // hit right wall
			return true;
		else if (py >= 600 && pvy > 0) // hit bottom wall
			return true;
		else if (py <= 40 && pvy < 0) // hit up wall
			return true;
		else 
			return false;
	}

	public static int generateRandInt(int min, int max)
	{
		Random r = new Random();
		
		int resualt = r.nextInt((max - min) + 1) + min ;
		
		return resualt;
	
	}
	
	public static point selectPoint(int x, int y) 
	{
		point return_pt = new point(x/40 , y/40);
		
		return return_pt;
		
	}
	
	
}

