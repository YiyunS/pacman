package application;

import java.io.IOException;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class Interface {
	
	public Pane first_page() throws IOException {
		
		Interface_Animation InAni = new Interface_Animation();
		
		Parent par = FXMLLoader.load(getClass().getResource("/application/GUI_P1.fxml"));
		
		Pane root =  new Pane();
		
		root.getChildren().addAll(InAni.setAnimation() ,par );
		
		return root;
		
	}
	
	public Pane press_start() throws IOException {
		
		Interface_Animation InAni = new Interface_Animation();
		
		Parent par = FXMLLoader.load(getClass().getResource("/application/GUI_P2.fxml"));
		
		Pane root =  new Pane();
		
		root.getChildren().addAll(InAni.setAnimation() ,par );
		
		return root;
		
	}
	
	public Pane setting() throws IOException {
		
		Pane root =  new Pane();
		
		Parent par = FXMLLoader.load(getClass().getResource("/application/GUI_SETTING.fxml"));
		
		
		Label LifeText = new Label("3");
		
			LifeText.setFont(new Font("Impact", 40));
			LifeText.setLayoutX(420);
			LifeText.setLayoutY(465);
			LifeText.setTextFill(Color.WHITE);
		

        Slider Lives = new Slider();
        	
        	Lives.setValue(3);
			
        	Lives.setPrefSize(200, 20);
			
			Lives.setLayoutX(200);
			Lives.setLayoutY(485);
			
			Lives.setMin(1);
			Lives.setMax(10);
        
			Lives.valueProperty().addListener(new ChangeListener<Object>() 
			{

				@Override
				public void changed(ObservableValue<?> arg0, Object arg1, Object arg2) 
					{
						LifeText.textProperty().setValue(String.valueOf((int) Lives.getValue()));
						board.defaultLife = (int)Lives.getValue();

					}
			}
			);
		
		
		root.getChildren().addAll(par,LifeText, Lives);
		
		return root;
	}
	
	

}
