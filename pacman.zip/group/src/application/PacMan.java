package application;

public class PacMan {
	static int px = 360;
	static int py = 560;
	static int press = 0;
	String face_to = null;
	int pvx;
	int pvy;
	int pcount = 0;
	
	void PacMove() 
	{	
		this.stop_pac();
		
		this.change_direction();
		
		this.eat_beans();
		
		this.teleport();
		
		this.proofreading();
		
		this.stop_moving();
		
		this.move();
		
		pcount++;
	}
	private void stop_pac() {
		if(press == 0) {
			pvx = 0;
			pvy = 0;
		}
	}
	private void move()
	{	
		if(pcount % 2 ==0 && board.Started)
		{px+=pvx;
		py+=pvy;}
	}
	
	private void eat_beans()
	{	
		//EAT right BEANS
		if ((board.arr[(px+17) / 40][(py ) / 40] ==  1) && ((px+17) % 40 == 0) && (py % 40 == 0))
		{
			
			board.arr[(px+17) / 40][(py ) / 40] = 0;
			board.Point+=10;
			board.Dot--;
			GameSound.playSound(GameSound.edot);
		}
		//EAT left BEANS
		else if ((board.arr[(px-17) / 40][(py ) / 40] ==  1) && ((px-17) % 40 == 0) && (py % 40 == 0))
		{
			
			board.arr[(px-17) / 40][(py ) / 40] = 0;
			board.Point+=10;
			board.Dot--;
			GameSound.playSound(GameSound.edot);
		}
		
		//EAT down BEANS
		else if ((board.arr[(px) / 40][(py +17) / 40] ==  1) && (px % 40 == 0) && ((py+17) % 40 == 0))
		{
					
			board.arr[(px) / 40][(py+17 ) / 40] = 0;
			board.Point+=10;
			board.Dot--;
			GameSound.playSound(GameSound.edot);
		}
		
		//EAT up BEANS
		else if ((board.arr[(px) / 40][(py -17) / 40] ==  1) && (px % 40 == 0) && ((py-17) % 40 == 0))
		{
							
			board.arr[(px) / 40][(py-17 ) / 40] = 0;
			board.Point+=10;
			board.Dot--;
			GameSound.playSound(GameSound.edot);
		}
		
				
		//EAT right BEANS
		if ((board.arr[(px+17) / 40][(py ) / 40] ==  4) && ((px+17) % 40 == 0) && (py % 40 == 0))
		{
			board.arr[(px+17) / 40][(py ) / 40] = 0;
			board.Point+=50;
			buff.TurnOn();
			GameSound.playSound(GameSound.eheart);
		}
		//EAT left BEANS
		else if ((board.arr[(px-17) / 40][(py ) / 40] ==  4) && ((px-17) % 40 == 0) && (py % 40 == 0))
		{
			board.arr[(px-17) / 40][(py ) / 40] = 0;
			board.Point+=50;
			buff.TurnOn();
			GameSound.playSound(GameSound.eheart);
		}
			//EAT down BEANS
			else if ((board.arr[(px) / 40][(py +17) / 40] ==  4) && (px % 40 == 0) && ((py+17) % 40 == 0))
		{
				board.arr[(px) / 40][(py+17 ) / 40] = 0;
				board.Point+=50;
				buff.TurnOn();
				GameSound.playSound(GameSound.eheart);
		}
			//EAT up BEANS
			else if ((board.arr[(px) / 40][(py -17) / 40] ==  4) && (px % 40 == 0) && ((py-17) % 40 == 0))
		{
				board.arr[(px) / 40][(py-17 ) / 40] = 0;
				board.Point+=50;
				buff.TurnOn();
				GameSound.playSound(GameSound.eheart);
		}	
	}
	
	
	private void stop_moving()
	{
		if (Movement.check_hit_wall(px, py , pvx, pvy)  || Movement.check_hit_obstacles( board.arr, px, py, face_to)  )
		{
			pvx = 0;
			pvy = 0;
		}
	}
	
	private void teleport()
	{
		if (px==40 && py>=300 && py<= 340 && pvx<0)
		{
			px=680;
			py=320;
		}
		
		if (px==680 && py>=300 && py<= 340 && pvx>0)
		{
			px=40;
			py=320;
		}
	}
	
	private void change_direction() 
	{
		if (face_to == "LEFT"&&press>0)
		{	
			pvy = 0;
			pvx = -1;
			press -= 1;
		}
		else if (face_to == "RIGHT"&&press>0)
		{
			pvy = 0;
			pvx = 1;
			press -= 1;
		}
		else if (face_to == "DOWN"&&press>0)
		{	
			pvx = 0;
			pvy = 1;
			press -= 1;
		}
		else if (face_to == "UP"&&press>0)
		{	
			pvx = 0;
			pvy = -1;
			press -= 1;
		}
		
	} 
	

	private void proofreading() 
	{
		if (face_to == "LEFT")
		{
			dwon_pro();
			up_pro();
		}
		else if (face_to == "RIGHT")
		{
			
			dwon_pro();
			up_pro( );
		}
		else if (face_to == "DOWN")
		{	left_pro();
			right_pro();
			
		}
		else if (face_to == "UP")
		{	
			right_pro();
			left_pro();
			
		}
	}
	
	  void right_pro() 
	{	
		if (
				( (px % 40) >= 30) 
			&&  ((px % 40) <= 39)
			&&  ( ((board.arr[px/40+1][py/40-1] != 2 && board.arr[px/40+1][py/40-1] != 3 ) && ( face_to =="UP"))  ||  ( (board.arr[px/40+1][py/40+1] != 2 && board.arr[px/40+1][py/40+1] != 3) && ( face_to =="DOWN") ) )
			)
		px = (px / 40 + 1) * 40;
	
	}
	
	  void left_pro()
	{	
		if ( 
				( (px % 40) <= 10) 
			 && ( (px % 40) >= 1) 
			 && (  ( (board.arr[px/40][py/40-1] != 2 && board.arr[px/40][py/40-1] != 3 ) && face_to =="UP")   ||   ( ( board.arr[px/40][py/40+1] != 2 && board.arr[px/40][py/40+1] != 3) && (face_to =="DOWN") ) )
			 ) //
		px = (px / 40 ) * 40;
		
	}
	//up down proceeding does not contradict os even if we put
	 void dwon_pro()
	{	
		if ( 
				((py % 40) >= 30) 
			 && ((py % 40) <= 39) 
			 && (   ( ( board.arr[px/40+1][py/40+1] != 2 && board.arr[px/40+1][py/40+1] !=3 ) && face_to =="RIGHT")   ||   ((board.arr[px/40-1][py/40+1] != 2 && board.arr[px/40-1][py/40+1] != 3) && face_to =="LEFT") ) 
			 )//
		py = (py / 40 + 1 ) * 40;
		
	}
	
	 void up_pro()
	{	
		if ( 
		       ((py % 40) <= 10) 
		    && ((py % 40) >= 1) 
		    && ( ( (board.arr[px/40+1][py/40]!=2 && board.arr[px/40+1][py/40] != 3)&& face_to =="RIGHT")   ||   ((board.arr[px/40-1][py/40]!=2 && board.arr[px/40-1][py/40] != 3 ) && face_to =="LEFT")   ) )// 
		py = (py / 40 ) * 40;
	
	}
	
	
	

}
