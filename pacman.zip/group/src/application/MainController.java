package application;

import java.io.IOException;
import javax.swing.JFrame;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;

public class MainController 
{

	
	@FXML
	private Button S1Exit;
	@FXML
	private Button S1start; 
	@FXML
	private Button S2Back; 
	@FXML
	private Button S2Setting; 
	@FXML
	private Button S2Play;
	@FXML
	private Button S2Apply;
	
	
	@FXML
	private CheckBox Kerry;
	@FXML
	private CheckBox David;
	@FXML
	private CheckBox Ian;
	@FXML
	private CheckBox Guizhen;
	@FXML
	private CheckBox Yiyun;
	

	
	
	
	public void switch_Scene2(ActionEvent event) throws IOException {
		
		//((Node)(event.getSource())).getScene().getWindow().hide();
		
		Stage TemperStage =  (Stage) S1start.getScene().getWindow();
		
		Interface GUI_2 = new Interface();
		
		Pane root = GUI_2.press_start();
		
		Scene scene = new Scene(root,480,480);
		
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			
		TemperStage.setScene(scene);
		TemperStage.show();
	}
	
	public void Exit_S1(ActionEvent event) throws IOException {
		
		System.exit(0);
	
	}
	
	public void Back_Scene1(ActionEvent event) throws IOException {
		
		//((Node)(event.getSource())).getScene().getWindow().hide();
		
		Stage TemperStage = (Stage) S2Back.getScene().getWindow();
		
		Interface GUI_1 = new Interface();
		
		Pane root = GUI_1.first_page();
		
		Scene scene = new Scene(root,480,480);
		
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());		
		TemperStage.setScene(scene);
		
		TemperStage.show();
	}
	
	public void Game(ActionEvent event) throws IOException{
		
		((Node)(event.getSource())).getScene().getWindow().hide();
		

		board gameBoard = new board();
		
		JFrame frame = new JFrame();
		
		frame.add(gameBoard);
		
		frame.setVisible(true);
		
		frame.setSize(760,800);
		
		frame.setLocation(500, 100);
		
		frame.setResizable(false);
		
		frame.setTitle("Pac-man");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		while (true)
		{
			gameBoard.askPrint();
		}

		
		
	}
	
	public void Scene2_Setting(ActionEvent event) throws IOException 
	{
		board.KerryRun = true;
		board.DavidRun = true;
		board.IanRun = false;
		board.GuizhenRun = true;
		board.YiyunRun = true;
		board.defaultLife = 3;

		
		
		Stage TemperStage = new Stage();
		
		TemperStage.initModality(Modality.APPLICATION_MODAL);
		
		Interface GUI_SETTING = new Interface();
		
		Pane root = GUI_SETTING.setting();

		//set as pop up stage
		
		Scene scene = new Scene(root,480,615);
		
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());	
		
		TemperStage.setScene(scene );
		
		TemperStage.setResizable(false);
			
		TemperStage.initOwner(S2Setting.getScene().getWindow());
		
		Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();
		TemperStage.setX(primaryScreenBounds.getMinX() + primaryScreenBounds.getWidth()-800);
		TemperStage.setY(primaryScreenBounds.getMinY() + primaryScreenBounds.getHeight()-900);
		
			
		TemperStage.showAndWait();
		
	}
	public void Apply(ActionEvent event) throws IOException 
	{
		((Node)(event.getSource())).getScene().getWindow().hide();
	}
	
	public void selectDavid(ActionEvent event) throws IOException 
	{
		if(David.isSelected())
		{
			board.DavidRun = true;
		}
		else
		{
			board.DavidRun = false;
		}
	}
	public void selectYiyun(ActionEvent event) throws IOException 
	{
		if(Yiyun.isSelected())
		{
			board.YiyunRun = true;
		}
		else
		{
			board.YiyunRun = false;
		}
	}
	public void selectIan(ActionEvent event) throws IOException 
	{
		if(Ian.isSelected())
		{
			board.IanRun = true;
		}
		else
		{
			board.IanRun = false;
		}
	}
	public void selectGuizhen(ActionEvent event) throws IOException 
	{
		if(Guizhen.isSelected())
		{
			board.GuizhenRun = true;
		}
		else
		{
			board.GuizhenRun = false;
		}
	}
	public void selectKerry(ActionEvent event) throws IOException 
	{
		if(Kerry.isSelected())
		{
			board.KerryRun = true;
	
		}
		else
		{
			board.KerryRun = false;
		}
	}





}


