package application;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class Test {
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static int[][] test1 = {{1,2,3},
{4,5,6},
{6,7,8}};

static int[][] test3 = {
		{2,2,2,2,2,2,2,2,2,2},
		{2,0,0,0,0,0,0,0,0,2},
		{2,2,2,2,0,2,0,2,2,2},
		{2,2,2,2,0,0,0,2,2,2},
		{2,2,2,2,2,2,2,2,2,2}
};

static int[][] test2 = {
{2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
{2,0,0,0,0,0,0,2,2,2,2,2,2,0,2,2,2,1,2,2,2,2,2,2,2},
{2,2,0,2,2,2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,2,2},
{2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2},
{2,0,0,2,2,2,0,2,2,2,0,2,2,0,2,0,2,2,2,2,2,5,2,2,2},
{2,2,2,2,0,0,0,0,0,0,0,2,2,0,0,0,0,2,2,2,2,2,2,2,2},
{2,2,2,2,0,2,2,2,0,2,0,2,2,0,2,0,2,2,2,2,2,2,2,2,2},
{2,2,2,2,0,2,2,2,0,2,0,2,2,0,2,0,2,2,2,2,2,2,2,2,2},
{2,2,2,2,2,2,2,2,0,2,2,2,2,0,2,0,2,2,2,2,2,2,2,2,2},
{2,2,2,2,2,2,2,2,0,2,2,2,2,0,2,0,0,2,2,2,2,2,2,2,2},
{2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2},
{2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	public static void main(String[] args) {
		
		

		/*
		ArrayList<Integer> arr = new ArrayList<Integer>(); 
		arr.add(0);
		arr.add(1);
		arr.add(2);
		arr.add(3);
		arr.add(5);
		arr.add(6);
		arr.add(9);
		arr.add(9);
		arr.add(9);
		arr.add(5);
		arr.add(10);
		
		//List<Integer> arr2 = arr.subList(1, 3);
		
		//arr.removeAll(arr.subList(arr.get(arr.indexOf(5)), arr.lastIndexOf(5)));
		
		//System.out.println(arr.indexOf(5));
		
		List<Integer> arr1 =  arr.subList(arr.indexOf(5), arr.lastIndexOf(5));
		for(int i = 0 ; i < arr1.size(); i++)
		{
			System.out.println(arr1.get(i));
		}
			
		*/
		
		
		
		int[][] arr = map.reset();
		findPath.print2DArr(arr);
		
		//findPath fp = new findPath(arr,Movement.selectPoint(520, 120), Movement.selectPoint(360,560));
		findPath fp = new findPath(arr, new point(13,3), new point(13,3));
		
		point[] path = fp.showPath();
		
		
		for(int i = 0; i< path.length;i++)
		{
			System.out.print(path[i].getX()+","+path[i].getY());
			
			System.out.println();
		}
		
		
		
		
		
		
		/*
		
		int[][] arr = test3;//map.reset2();
		findPath.print2DArr(arr);
		
		findPath fp = new findPath(arr,new point(1,1), new point(1,8));
		
		point[] path = fp.showPath();
		
		
		
		
		
		for(int i = 0; i< path.length;i++)
		{
			System.out.print(path[i].getX()+","+path[i].getY());
			
			System.out.println();
		}
		
		
		
		
		
		/*
		int[][] arr = map.reset();
		
		point start = Movement.selectPoint(360, 120);
		
		point end = Movement.selectPoint(360, 560);
		
		findPath.print2DArr(arr);
		
		findPath fp = new findPath(arr, start, end);
		
		point[] path = fp.showPath();
		
		System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
		
		
		for(int i = 0; i< path.length;i++)
		{
			System.out.print(path[0].getX()+","+path[0].getY());
			
			//System.out.println();
		}
		*/
		
		
		//System.out.println(((point) arr[0]).getX()+","+((point) arr[0]).getY());

	}

}
