package application;


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class findPath {

	
	private point start;
	
	private point end;
	
	private int[][] maze;
	
	private point[][] ptMaze;
	
	public findPath(int[][] new_maze, point s, point e) 
	{
		this.maze = new_maze;
		this.start = s;
		this.end = e;
		this.ptMaze = point.pointArr(maze);
	}
	
	
	
	
	public point[] showPath()
	{
		int a = this.showPath1().length;
		
		int b = this.showPath2().length;
		
		int c = this.showPath3().length;
		
		int d = this.showPath4().length;
		
		int e = this.showPath5().length;
		
		int f = this.showPath6().length;
		
		if (a <= b  && a <= c && a <= d && a<=e&& a<=f)
		{
			return this.showPath1();
		}
		
		else if (b <= a && b <= c && b <= d && b<= e && b<=f) 
		{
			return this.showPath2();
		}
		
		else if (c <= a && c <= b && c <= d && c<=e && c<=f) 
			
			return this.showPath3();
		else if (d <= a && d <= b && d <= c && d <= e && d <=f) 
			return this.showPath4();
		
		else if (e <= a && e <= b && e <= c && e <= d && e <=f) 
			return this.showPath5();
		
		else 
			return this.showPath6();
	}
	
	

	
	
	
	private point[] showPath1()
	{	
		
		//ArrayList<point> collection = new ArrayList<point>();
		
		int[][] copy_maze = copy(maze);
		
		ArrayList<point> stack = new ArrayList<point>();

		
		stack.add(start);
		//collection.add(start);
		
		if(start.getX() == end.getX() && start.getY() == end.getY())
		{
			point[] path = new point[1];
			path[0] = start;
			return path;
		}
		
		while(true)
		{
			
			//System.out.println(stack.get(stack.size()-1).getX()+","+stack.get(stack.size()-1).getY());
			

			//System.out.println(stack.size()+" "+stack.get(stack.size() -1).getX()+" "+ stack.get(stack.size()-1).getY());
			
				if(this.possible_Way1(copy_maze, stack.get(stack.size()-1), stack).size() != 0 )
			{	
				
				point add = null;
					
				if(this.possible_Way1(copy_maze, stack.get(stack.size()-1), stack).get(0) == "UP")
				{
					add = ptMaze[stack.get(stack.size()-1).getX()][stack.get(stack.size()-1).getY() - 1];
					//stack.push( ptMaze[stack.peek().getX()][stack.peek().getY() - 1] );
					//collection.add(e)
					
				}
				else if(this.possible_Way1(copy_maze, stack.get(stack.size()-1), stack).get(0) == "RIGHT")
				{
					add = ptMaze[stack.get(stack.size()-1).getX() + 1][stack.get(stack.size()-1).getY()];
					//stack.push(new point(stack.peek().getX() + 1 , stack.peek().getY()) );
				}
				else if(this.possible_Way1(copy_maze, stack.get(stack.size()-1) ,  stack).get(0) == "DOWN")
				{
					add = ptMaze[stack.get(stack.size()-1).getX()][stack.get(stack.size()-1).getY()+1];
					
					//System.out.println("down");
					
					//stack.push(new point(stack.peek().getX() , stack.peek().getX()) );
				}
				else if(this.possible_Way1(copy_maze, stack.get(stack.size()-1), stack).get(0) == "LEFT")
				{
					add = ptMaze[stack.get(stack.size()-1).getX() - 1][stack.get(stack.size()-1).getY()];
					
					//stack.push(new point(stack.peek().getX() - 1 , stack.peek().getY() ) );
				}
				
				
				if(! stack.contains(add) )
				
				{stack.add(add);}
				else
				{	stack.add(add);
					copy_maze[ stack. get (stack. indexOf ( add ) + 1).getX()][stack. get (stack . indexOf ( add ) + 1).getY()] = 2;
					stack.removeAll(stack.subList(stack.indexOf(add), stack.lastIndexOf(add)));
					
					//System.out.println(stack.size());
				}
				
				
				
			}	
				
			
			else
			{
				copy_maze[stack.get(stack.size()-1).getX()][ stack.get(stack.size()-1).getY()] = 2;
				stack.remove(stack.size()-1);
			}
			
			//System.out.println(stack.get(stack.size()-1).getX()+","+stack.get(stack.size()-1).getY());
			
				if(!stack.isEmpty())
				{
					if(stack.get(stack.size()-1).getX() == end.getX() && stack.get(stack.size()-1).getY() == end.getY())
						break;
				}
				else
					break;
			
			
		}
		
		point[] path = new point[stack.size()];
		
		for (int i = 0 ;i < stack.size() ; i++ )
			{path[i] = stack.get(i);}
		
		
		//print2DArr(copy_maze);
		
		//System.out.println(stack.peek().getX()+","+stack.peek().getY());
		return path;
	}
	
	
	private point[] showPath2()
	{	
		
		//ArrayList<point> collection = new ArrayList<point>();
		
		int[][] copy_maze = copy(maze);
		
		ArrayList<point> stack = new ArrayList<point>();

		
		stack.add(start);
		
		if(start.getX() == end.getX() && start.getY() == end.getY())
		{
			point[] path = new point[1];
			path[0] = start;
			return path;
		}
		//collection.add(start);
		
		while(true)
		{
			
			//System.out.println(stack.get(stack.size()-1).getX()+","+stack.get(stack.size()-1).getY());
			
				if(this.possible_Way2(copy_maze, stack.get(stack.size()-1), stack).size() != 0 )
			{	
				
				point add = null;
					
				if(this.possible_Way2(copy_maze, stack.get(stack.size()-1), stack).get(0) == "UP")
				{
					add = ptMaze[stack.get(stack.size()-1).getX()][stack.get(stack.size()-1).getY() - 1];
					//stack.push( ptMaze[stack.peek().getX()][stack.peek().getY() - 1] );
					//collection.add(e)
					
				}
				else if(this.possible_Way2(copy_maze, stack.get(stack.size()-1), stack).get(0) == "RIGHT")
				{
					add = ptMaze[stack.get(stack.size()-1).getX() + 1][stack.get(stack.size()-1).getY()];
					//stack.push(new point(stack.peek().getX() + 1 , stack.peek().getY()) );
				}
				else if(this.possible_Way2(copy_maze, stack.get(stack.size()-1) ,  stack).get(0) == "DOWN")
				{
					add = ptMaze[stack.get(stack.size()-1).getX()][stack.get(stack.size()-1).getY()+1];
					
					//System.out.println("down");
					
					//stack.push(new point(stack.peek().getX() , stack.peek().getX()) );
				}
				else if(this.possible_Way2(copy_maze, stack.get(stack.size()-1), stack).get(0) == "LEFT")
				{
					add = ptMaze[stack.get(stack.size()-1).getX() - 1][stack.get(stack.size()-1).getY()];
					
					//stack.push(new point(stack.peek().getX() - 1 , stack.peek().getY() ) );
				}
				
				
				if(! stack.contains(add) )
				
				{stack.add(add);}
				else
				{	stack.add(add);
					copy_maze[ stack. get (stack. indexOf ( add ) + 1).getX()][stack. get (stack . indexOf ( add ) + 1).getY()] = 2;
					stack.removeAll(stack.subList(stack.indexOf(add), stack.lastIndexOf(add)));
				}
				
				
				
			}	
				
			
			else
			{
				copy_maze[stack.get(stack.size()-1).getX()][ stack.get(stack.size()-1).getY()] = 2;
				stack.remove(stack.size()-1);
			}
			
			//System.out.println(stack.get(stack.size()-1).getX()+","+stack.get(stack.size()-1).getY());
			if(!stack.isEmpty())
			{
				if(stack.get(stack.size()-1).getX() == end.getX() && stack.get(stack.size()-1).getY() == end.getY())
					break;
			}
			else
				break;
			
			
		}
		
		point[] path = new point[stack.size()];
		
		for (int i = 0 ;i < stack.size() ; i++ )
			{path[i] = stack.get(i);}
		
		
		//print2DArr(copy_maze);
		
		//System.out.println(stack.peek().getX()+","+stack.peek().getY());
		return path;
	}
	
	private point[] showPath3()
	{	
		
		//ArrayList<point> collection = new ArrayList<point>();
		
		int[][] copy_maze = copy(maze);
		
		ArrayList<point> stack = new ArrayList<point>();

		
		stack.add(start);
		//collection.add(start);
		if(start.getX() == end.getX() && start.getY() == end.getY())
		{
			point[] path = new point[1];
			path[0] = start;
			return path;
		}
		
		while(true)
		{
			
			//System.out.println(stack.get(stack.size()-1).getX()+","+stack.get(stack.size()-1).getY());
			

			//System.out.println(stack.size()+" "+stack.get(stack.size() -1).getX()+" "+ stack.get(stack.size()-1).getY());
			
				if(this.possible_Way3(copy_maze, stack.get(stack.size()-1), stack).size() != 0 )
			{	
				
				point add = null;
					
				if(this.possible_Way3(copy_maze, stack.get(stack.size()-1), stack).get(0) == "UP")
				{
					add = ptMaze[stack.get(stack.size()-1).getX()][stack.get(stack.size()-1).getY() - 1];
					//stack.push( ptMaze[stack.peek().getX()][stack.peek().getY() - 1] );
					//collection.add(e)
					
				}
				else if(this.possible_Way3(copy_maze, stack.get(stack.size()-1), stack).get(0) == "RIGHT")
				{
					add = ptMaze[stack.get(stack.size()-1).getX() + 1][stack.get(stack.size()-1).getY()];
					//stack.push(new point(stack.peek().getX() + 1 , stack.peek().getY()) );
				}
				else if(this.possible_Way3(copy_maze, stack.get(stack.size()-1) ,  stack).get(0) == "DOWN")
				{
					add = ptMaze[stack.get(stack.size()-1).getX()][stack.get(stack.size()-1).getY()+1];
					
					//System.out.println("down");
					
					//stack.push(new point(stack.peek().getX() , stack.peek().getX()) );
				}
				else if(this.possible_Way3(copy_maze, stack.get(stack.size()-1), stack).get(0) == "LEFT")
				{
					add = ptMaze[stack.get(stack.size()-1).getX() - 1][stack.get(stack.size()-1).getY()];
					
					//stack.push(new point(stack.peek().getX() - 1 , stack.peek().getY() ) );
				}
				
				
				if(! stack.contains(add) )
				
				{stack.add(add);}
				else
				{	stack.add(add);
					copy_maze[ stack. get (stack. indexOf ( add ) + 1).getX()][stack. get (stack . indexOf ( add ) + 1).getY()] = 2;
					stack.removeAll(stack.subList(stack.indexOf(add), stack.lastIndexOf(add)));
					
					//System.out.println(stack.size());
				}
				
				
				
			}	
				
			
			else
			{
				copy_maze[stack.get(stack.size()-1).getX()][ stack.get(stack.size()-1).getY()] = 2;
				stack.remove(stack.size()-1);
			}
			
			//System.out.println(stack.get(stack.size()-1).getX()+","+stack.get(stack.size()-1).getY());
			
				if(!stack.isEmpty())
				{
					if(stack.get(stack.size()-1).getX() == end.getX() && stack.get(stack.size()-1).getY() == end.getY())
						break;
				}
				else
					break;
			
			
		}
		
		point[] path = new point[stack.size()];
		
		for (int i = 0 ;i < stack.size() ; i++ )
			{path[i] = stack.get(i);}
		
		
		//print2DArr(copy_maze);
		
		//System.out.println(stack.peek().getX()+","+stack.peek().getY());
		return path;
	}

	
	public point[] showPath5()
	{	
		
		//ArrayList<point> collection = new ArrayList<point>();
		
		int[][] copy_maze = copy(maze);
		
		ArrayList<point> stack = new ArrayList<point>();

		
		stack.add(start);
		//collection.add(start);
		if(start.getX() == end.getX() && start.getY() == end.getY())
		{
			point[] path = new point[1];
			path[0] = start;
			return path;
		}
		
		while(true)
		{
			
			//System.out.println(stack.get(stack.size()-1).getX()+","+stack.get(stack.size()-1).getY());
			

			//System.out.println(stack.size()+" "+stack.get(stack.size() -1).getX()+" "+ stack.get(stack.size()-1).getY());
			
				if(this.possible_Way5(copy_maze, stack.get(stack.size()-1), stack).size() != 0 )
			{	
				
				point add = null;
					
				if(this.possible_Way5(copy_maze, stack.get(stack.size()-1), stack).get(0) == "UP")
				{
					add = ptMaze[stack.get(stack.size()-1).getX()][stack.get(stack.size()-1).getY() - 1];
					//stack.push( ptMaze[stack.peek().getX()][stack.peek().getY() - 1] );
					//collection.add(e)
					
				}
				else if(this.possible_Way5(copy_maze, stack.get(stack.size()-1), stack).get(0) == "RIGHT")
				{
					add = ptMaze[stack.get(stack.size()-1).getX() + 1][stack.get(stack.size()-1).getY()];
					//stack.push(new point(stack.peek().getX() + 1 , stack.peek().getY()) );
				}
				else if(this.possible_Way5(copy_maze, stack.get(stack.size()-1) ,  stack).get(0) == "DOWN")
				{
					add = ptMaze[stack.get(stack.size()-1).getX()][stack.get(stack.size()-1).getY()+1];
					
					//System.out.println("down");
					
					//stack.push(new point(stack.peek().getX() , stack.peek().getX()) );
				}
				else if(this.possible_Way5(copy_maze, stack.get(stack.size()-1), stack).get(0) == "LEFT")
				{
					add = ptMaze[stack.get(stack.size()-1).getX() - 1][stack.get(stack.size()-1).getY()];
					
					//stack.push(new point(stack.peek().getX() - 1 , stack.peek().getY() ) );
				}
				
				
				if(! stack.contains(add) )
				
				{stack.add(add);}
				else
				{	stack.add(add);
					copy_maze[ stack. get (stack. indexOf ( add ) + 1).getX()][stack. get (stack . indexOf ( add ) + 1).getY()] = 2;
					stack.removeAll(stack.subList(stack.indexOf(add), stack.lastIndexOf(add)));
					
					//System.out.println(stack.size());
				}
				
				
				
			}	
				
			
			else
			{
				copy_maze[stack.get(stack.size()-1).getX()][ stack.get(stack.size()-1).getY()] = 2;
				stack.remove(stack.size()-1);
			}
			
			//System.out.println(stack.get(stack.size()-1).getX()+","+stack.get(stack.size()-1).getY());
			
				if(!stack.isEmpty())
				{
					if(stack.get(stack.size()-1).getX() == end.getX() && stack.get(stack.size()-1).getY() == end.getY())
						break;
				}
				else
					break;
			
			
		}
		
		point[] path = new point[stack.size()];
		
		for (int i = 0 ;i < stack.size() ; i++ )
			{path[i] = stack.get(i);}
		
		
		//print2DArr(copy_maze);
		
		//System.out.println(stack.peek().getX()+","+stack.peek().getY());
		return path;
	}

	
	
	public point[] showPath4()
	{	
		
		//ArrayList<point> collection = new ArrayList<point>();
		
		int[][] copy_maze = copy(maze);
		
		ArrayList<point> stack = new ArrayList<point>();

		
		stack.add(start);
		//collection.add(start);
		if(start.getX() == end.getX() && start.getY() == end.getY())
		{
			point[] path = new point[1];
			path[0] = start;
			return path;
		}
		
		while(true)
		{
			
			//System.out.println(stack.get(stack.size()-1).getX()+","+stack.get(stack.size()-1).getY());
			

			//System.out.println(stack.size()+" "+stack.get(stack.size() -1).getX()+" "+ stack.get(stack.size()-1).getY());
			
				if(this.possible_Way4(copy_maze, stack.get(stack.size()-1), stack).size() != 0 )
			{	
				
				point add = null;
					
				if(this.possible_Way4(copy_maze, stack.get(stack.size()-1), stack).get(0) == "UP")
				{
					add = ptMaze[stack.get(stack.size()-1).getX()][stack.get(stack.size()-1).getY() - 1];
					//stack.push( ptMaze[stack.peek().getX()][stack.peek().getY() - 1] );
					//collection.add(e)
					
				}
				else if(this.possible_Way4(copy_maze, stack.get(stack.size()-1), stack).get(0) == "RIGHT")
				{
					add = ptMaze[stack.get(stack.size()-1).getX() + 1][stack.get(stack.size()-1).getY()];
					//stack.push(new point(stack.peek().getX() + 1 , stack.peek().getY()) );
				}
				else if(this.possible_Way4(copy_maze, stack.get(stack.size()-1) ,  stack).get(0) == "DOWN")
				{
					add = ptMaze[stack.get(stack.size()-1).getX()][stack.get(stack.size()-1).getY()+1];
					
					//System.out.println("down");
					
					//stack.push(new point(stack.peek().getX() , stack.peek().getX()) );
				}
				else if(this.possible_Way4(copy_maze, stack.get(stack.size()-1), stack).get(0) == "LEFT")
				{
					add = ptMaze[stack.get(stack.size()-1).getX() - 1][stack.get(stack.size()-1).getY()];
					
					//stack.push(new point(stack.peek().getX() - 1 , stack.peek().getY() ) );
				}
				
				
				if(! stack.contains(add) )
				
				{stack.add(add);}
				else
				{	stack.add(add);
					copy_maze[ stack. get (stack. indexOf ( add ) + 1).getX()][stack. get (stack . indexOf ( add ) + 1).getY()] = 2;
					stack.removeAll(stack.subList(stack.indexOf(add), stack.lastIndexOf(add)));
					
					//System.out.println(stack.size());
				}
				
				
				
			}	
				
			
			else
			{
				copy_maze[stack.get(stack.size()-1).getX()][ stack.get(stack.size()-1).getY()] = 2;
				stack.remove(stack.size()-1);
			}
			
			//System.out.println(stack.get(stack.size()-1).getX()+","+stack.get(stack.size()-1).getY());
			
				if(!stack.isEmpty())
				{
					if(stack.get(stack.size()-1).getX() == end.getX() && stack.get(stack.size()-1).getY() == end.getY())
						break;
				}
				else
					break;
			
			
		}
		
		point[] path = new point[stack.size()];
		
		for (int i = 0 ;i < stack.size() ; i++ )
			{path[i] = stack.get(i);}
		
		
		//print2DArr(copy_maze);
		
		//System.out.println(stack.peek().getX()+","+stack.peek().getY());
		return path;
	}
	
	public point[] showPath6()
	{	
		
		//ArrayList<point> collection = new ArrayList<point>();
		
		int[][] copy_maze = copy(maze);
		
		ArrayList<point> stack = new ArrayList<point>();

		
		stack.add(start);
		//collection.add(start);
		if(start.getX() == end.getX() && start.getY() == end.getY())
		{
			point[] path = new point[1];
			path[0] = start;
			return path;
		}
		
		while(true)
		{
			
			//System.out.println(stack.get(stack.size()-1).getX()+","+stack.get(stack.size()-1).getY());
			

			//System.out.println(stack.size()+" "+stack.get(stack.size() -1).getX()+" "+ stack.get(stack.size()-1).getY());
			
				if(this.possible_Way6(copy_maze, stack.get(stack.size()-1), stack).size() != 0 )
			{	
				
				point add = null;
					
				if(this.possible_Way6(copy_maze, stack.get(stack.size()-1), stack).get(0) == "UP")
				{
					add = ptMaze[stack.get(stack.size()-1).getX()][stack.get(stack.size()-1).getY() - 1];
					//stack.push( ptMaze[stack.peek().getX()][stack.peek().getY() - 1] );
					//collection.add(e)
					
				}
				else if(this.possible_Way6(copy_maze, stack.get(stack.size()-1), stack).get(0) == "RIGHT")
				{
					add = ptMaze[stack.get(stack.size()-1).getX() + 1][stack.get(stack.size()-1).getY()];
					//stack.push(new point(stack.peek().getX() + 1 , stack.peek().getY()) );
				}
				else if(this.possible_Way6(copy_maze, stack.get(stack.size()-1) ,  stack).get(0) == "DOWN")
				{
					add = ptMaze[stack.get(stack.size()-1).getX()][stack.get(stack.size()-1).getY()+1];
					
					//System.out.println("down");
					
					//stack.push(new point(stack.peek().getX() , stack.peek().getX()) );
				}
				else if(this.possible_Way6(copy_maze, stack.get(stack.size()-1), stack).get(0) == "LEFT")
				{
					add = ptMaze[stack.get(stack.size()-1).getX() - 1][stack.get(stack.size()-1).getY()];
					
					//stack.push(new point(stack.peek().getX() - 1 , stack.peek().getY() ) );
				}
				
				
				if(! stack.contains(add) )
				
				{stack.add(add);}
				else
				{	stack.add(add);
					copy_maze[ stack. get (stack. indexOf ( add ) + 1).getX()][stack. get (stack . indexOf ( add ) + 1).getY()] = 2;
					stack.removeAll(stack.subList(stack.indexOf(add), stack.lastIndexOf(add)));
					
					//System.out.println(stack.size());
				}
				
				
				
			}	
				
			
			else
			{
				copy_maze[stack.get(stack.size()-1).getX()][ stack.get(stack.size()-1).getY()] = 2;
				stack.remove(stack.size()-1);
			}
			
			//System.out.println(stack.get(stack.size()-1).getX()+","+stack.get(stack.size()-1).getY());
			
				if(!stack.isEmpty())
				{
					if(stack.get(stack.size()-1).getX() == end.getX() && stack.get(stack.size()-1).getY() == end.getY())
						break;
				}
				else
					break;
			
			
		}
		
		point[] path = new point[stack.size()];
		
		for (int i = 0 ;i < stack.size() ; i++ )
			{path[i] = stack.get(i);}
		
		
		//print2DArr(copy_maze);
		
		//System.out.println(stack.peek().getX()+","+stack.peek().getY());
		return path;
	}

	
	
	
	
	
	
	


	public static int[][] copy(int[][] input)
	{
		int[][] copy = new int[input.length][input[0].length];
		
		for(int i  = 0 ; i < input.length ; i ++ )
		{
			for(int j  = 0 ; j < input[0].length ; j ++ )
			{
				copy[i][j] = input[i][j];
			}
		}
		
		return copy;
			
	}
	
	public static void print2DArr(int[][] input) 
	{
		for(int i  = 0 ; i < input[0].length ; i ++ )
		{
			for(int j  = 0 ; j < input.length ; j ++ )
			{
				System.out.print(input[j][i]+" ");
			}
			
			System.out.println();
		}
		
		System.out.println();
	}
	
	private ArrayList<String> possible_Way1(int[][] maze, point pt, ArrayList<point> stack) 
	{	
		
		
		ArrayList<String> PW = new ArrayList<String>();
		
		if( maze[pt.getX()][pt.getY() - 1] != 2 && maze[pt.getX()][pt.getY() - 1] != 3  )
			
			{if(stack.size() == 1)
				

				
				PW.add("UP");
			
			else if( stack.get(stack.size() - 2).getX() != pt.getX()  ||  stack.get(stack.size() - 2).getY() != pt.getY() -1  )
				
			
				PW.add("UP");  
			
			
			}
				
				
		
		if( maze[pt.getX() + 1][pt.getY() ] != 2 && maze[pt.getX() + 1][pt.getY() ] != 3 )
			
			{if(stack.size() == 1)
				
				PW.add("RIGHT");
			
			else if (stack.get(stack.size() - 2).getX() != pt.getX() + 1  ||  stack.get(stack.size() - 2).getY() != pt.getY() )
				
				PW.add("RIGHT");
			
			
			}
		
		
		if( maze[pt.getX()][pt.getY() + 1] != 2 && maze[pt.getX()][pt.getY() + 1] != 3 )
			
			{if(stack.size() == 1)
			
				PW.add("DOWN");
		
		
			else if ( stack.get(stack.size() - 2).getX() != pt.getX()  ||  stack.get(stack.size() - 2).getY() != pt.getY() + 1)
			
				
				PW.add("DOWN");
			
			
			
			
			}
		
		
		if( maze[pt.getX() - 1][pt.getY() ] != 2 && maze[pt.getX() - 1][pt.getY() ] != 3 )
			
			{if(stack.size() == 1)
			
				PW.add("LEFT");
			
			else if ( stack.get(stack.size() - 2).getX() != pt.getX() - 1 ||  stack.get(stack.size() - 2).getY() != pt.getY())
				
				PW.add("LEFT");
			
			
			}
		
		
		return PW;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	private ArrayList<String> possible_Way2(int[][] maze, point pt, ArrayList<point> stack) 
	{	
		
		
		ArrayList<String> PW = new ArrayList<String>();
		
		
		
		if( maze[pt.getX()][pt.getY() + 1] != 2 && maze[pt.getX()][pt.getY() + 1] != 3 )
			
			{if(stack.size() == 1)
			
				PW.add("DOWN");
		
		
			else if ( stack.get(stack.size() - 2).getX() != pt.getX()  ||  stack.get(stack.size() - 2).getY() != pt.getY() + 1)
			
				
				PW.add("DOWN");
			
			
			
			
			}
		if( maze[pt.getX() - 1][pt.getY() ] != 2 && maze[pt.getX() - 1][pt.getY() ] != 3 )
			
			{if(stack.size() == 1)
			
				PW.add("LEFT");
			
			else if ( stack.get(stack.size() - 2).getX() != pt.getX() - 1 ||  stack.get(stack.size() - 2).getY() != pt.getY())
				
				PW.add("LEFT");
			
			
			}
		
		if( maze[pt.getX()][pt.getY() - 1] != 2 && maze[pt.getX()][pt.getY() - 1] != 3  )
			
			{if(stack.size() == 1)
				

				
				PW.add("UP");
			
			else if( stack.get(stack.size() - 2).getX() != pt.getX()  ||  stack.get(stack.size() - 2).getY() != pt.getY() -1  )
				
			
				PW.add("UP");  
			
			
			}
		if( maze[pt.getX() + 1][pt.getY() ] != 2 && maze[pt.getX() + 1][pt.getY() ] != 3 )
			
			{if(stack.size() == 1)
				
				PW.add("RIGHT");
			
			else if (stack.get(stack.size() - 2).getX() != pt.getX() + 1  ||  stack.get(stack.size() - 2).getY() != pt.getY() )
				
				PW.add("RIGHT");
			
			
			}
		

		
		return PW;
		
	}
	

	
	private ArrayList<String> possible_Way3(int[][] maze, point pt, ArrayList<point> stack) 
	{	
		
		
		ArrayList<String> PW = new ArrayList<String>();
		
		
		if( maze[pt.getX() - 1][pt.getY() ] != 2 && maze[pt.getX() - 1][pt.getY() ] != 3 )
			
		{if(stack.size() == 1)
		
			PW.add("LEFT");
		
		else if ( stack.get(stack.size() - 2).getX() != pt.getX() - 1 ||  stack.get(stack.size() - 2).getY() != pt.getY())
			
			PW.add("LEFT");
		
		
		}
		
		
		
		if( maze[pt.getX()][pt.getY() - 1] != 2 && maze[pt.getX()][pt.getY() - 1] != 3  )
			
			{if(stack.size() == 1)
				

				
				PW.add("UP");
			
			else if( stack.get(stack.size() - 2).getX() != pt.getX()  ||  stack.get(stack.size() - 2).getY() != pt.getY() -1  )
				
			
				PW.add("UP");  
			
			
			}
				
				
		
		if( maze[pt.getX() + 1][pt.getY() ] != 2 && maze[pt.getX() + 1][pt.getY() ] != 3 )
			
			{if(stack.size() == 1)
				
				PW.add("RIGHT");
			
			else if (stack.get(stack.size() - 2).getX() != pt.getX() + 1  ||  stack.get(stack.size() - 2).getY() != pt.getY() )
				
				PW.add("RIGHT");
			
			
			}
		
		
		if( maze[pt.getX()][pt.getY() + 1] != 2 && maze[pt.getX()][pt.getY() + 1] != 3 )
			
			{if(stack.size() == 1)
			
				PW.add("DOWN");
		
		
			else if ( stack.get(stack.size() - 2).getX() != pt.getX()  ||  stack.get(stack.size() - 2).getY() != pt.getY() + 1)
			
				
				PW.add("DOWN");
			
			
			
			
			}
		
		
		
		
		
		return PW;
		
	
	}
	
	private ArrayList<String> possible_Way4(int[][] maze, point pt, ArrayList<point> stack) 
	{	
		
		
		ArrayList<String> PW = new ArrayList<String>();
		
		
		if( maze[pt.getX() - 1][pt.getY() ] != 2 && maze[pt.getX() - 1][pt.getY() ] != 3 )
			
		{if(stack.size() == 1)
	
			PW.add("LEFT");
	
		else if ( stack.get(stack.size() - 2).getX() != pt.getX() - 1 ||  stack.get(stack.size() - 2).getY() != pt.getY())
		
			PW.add("LEFT");
	
	
		}
		
		
		if( maze[pt.getX()][pt.getY() + 1] != 2 && maze[pt.getX()][pt.getY() + 1] != 3 )
			
			{if(stack.size() == 1)
			
				PW.add("DOWN");
		
		
			else if ( stack.get(stack.size() - 2).getX() != pt.getX()  ||  stack.get(stack.size() - 2).getY() != pt.getY() + 1)
			
				
				PW.add("DOWN");
			}
		
		
		
		if( maze[pt.getX() + 1][pt.getY() ] != 2 && maze[pt.getX() + 1][pt.getY() ] != 3 )
			
			{if(stack.size() == 1)
			
				PW.add("RIGHT");
		
			else if (stack.get(stack.size() - 2).getX() != pt.getX() + 1  ||  stack.get(stack.size() - 2).getY() != pt.getY() )
			
				PW.add("RIGHT");
		
		
			}
		
		
		if( maze[pt.getX()][pt.getY() - 1] != 2 && maze[pt.getX()][pt.getY() - 1] != 3  )
			
			{if(stack.size() == 1)
			

			
				PW.add("UP");
		
			else if( stack.get(stack.size() - 2).getX() != pt.getX()  ||  stack.get(stack.size() - 2).getY() != pt.getY() -1  )
			
		
				PW.add("UP");  
		
		
			}
		
		
		
		
		
	
		return PW;
		
	}
	

	private ArrayList<String> possible_Way5(int[][] maze, point pt, ArrayList<point> stack) 
	{	
		
		
		ArrayList<String> PW = new ArrayList<String>();
		
		
		
		
		
		if( maze[pt.getX()][pt.getY() + 1] != 2 && maze[pt.getX()][pt.getY() + 1] != 3 )
			
			{if(stack.size() == 1)
			
				PW.add("DOWN");
		
		
			else if ( stack.get(stack.size() - 2).getX() != pt.getX()  ||  stack.get(stack.size() - 2).getY() != pt.getY() + 1)
			
				
				PW.add("DOWN");
			}
		
		
		
		if( maze[pt.getX() + 1][pt.getY() ] != 2 && maze[pt.getX() + 1][pt.getY() ] != 3 )
			
			{if(stack.size() == 1)
			
				PW.add("RIGHT");
		
			else if (stack.get(stack.size() - 2).getX() != pt.getX() + 1  ||  stack.get(stack.size() - 2).getY() != pt.getY() )
			
				PW.add("RIGHT");
		
		
			}
		
		
		if( maze[pt.getX()][pt.getY() - 1] != 2 && maze[pt.getX()][pt.getY() - 1] != 3  )
			
			{if(stack.size() == 1)
			

			
				PW.add("UP");
		
			else if( stack.get(stack.size() - 2).getX() != pt.getX()  ||  stack.get(stack.size() - 2).getY() != pt.getY() -1  )
			
		
				PW.add("UP");  
		
		
			}
		if( maze[pt.getX() - 1][pt.getY() ] != 2 && maze[pt.getX() - 1][pt.getY() ] != 3 )
			
			{if(stack.size() == 1)
	
				PW.add("LEFT");
	
			else if ( stack.get(stack.size() - 2).getX() != pt.getX() - 1 ||  stack.get(stack.size() - 2).getY() != pt.getY())
		
				PW.add("LEFT");
	
	
			}
	
		return PW;
		
	}
	
	private ArrayList<String> possible_Way6(int[][] maze, point pt, ArrayList<point> stack) 
	{	
		
		
		ArrayList<String> PW = new ArrayList<String>();
		
	
				
				
		
		if( maze[pt.getX() + 1][pt.getY() ] != 2 && maze[pt.getX() + 1][pt.getY() ] != 3 )
			
			{if(stack.size() == 1)
				
				PW.add("RIGHT");
			
			else if (stack.get(stack.size() - 2).getX() != pt.getX() + 1  ||  stack.get(stack.size() - 2).getY() != pt.getY() )
				
				PW.add("RIGHT");
			
			
			}
		
		
		if( maze[pt.getX()][pt.getY() + 1] != 2 && maze[pt.getX()][pt.getY() + 1] != 3 )
			
			{if(stack.size() == 1)
			
				PW.add("DOWN");
		
		
			else if ( stack.get(stack.size() - 2).getX() != pt.getX()  ||  stack.get(stack.size() - 2).getY() != pt.getY() + 1)
			
				
				PW.add("DOWN");
			
			
			
			
			}
		
		
		if( maze[pt.getX() - 1][pt.getY() ] != 2 && maze[pt.getX() - 1][pt.getY() ] != 3 )
			
			{if(stack.size() == 1)
			
				PW.add("LEFT");
			
			else if ( stack.get(stack.size() - 2).getX() != pt.getX() - 1 ||  stack.get(stack.size() - 2).getY() != pt.getY())
				
				PW.add("LEFT");
			
			
			}
		if( maze[pt.getX()][pt.getY() - 1] != 2 && maze[pt.getX()][pt.getY() - 1] != 3  )
			
		{if(stack.size() == 1)
			

			
			PW.add("UP");
		
		else if( stack.get(stack.size() - 2).getX() != pt.getX()  ||  stack.get(stack.size() - 2).getY() != pt.getY() -1  )
			
		
			PW.add("UP");  
		
		
		}
		
		return PW;
		
	}
	
	public static List<String> possible_move(int x , int y, int vx, int vy) 
	{List<String> possible_move = new LinkedList<>();
	
	
	
	if (y % 40 == 0 && map.beanMtx[x/40 +1][y/40] != 3 && map.beanMtx[x/40 +1][y/40] != 2 && vx != -1)
	{
		possible_move.add("RIGHT");
	}
	
	if (x % 40 == 0 && map.beanMtx[x/40][y/40 + 1] != 3 && map.beanMtx[x / 40][y / 40 + 1] != 2 && vy != -1)
	{
		possible_move.add("DOWN");
	}
	
	if (y % 40 == 0 && map.beanMtx[x/40 - 1][y/40] != 3 && map.beanMtx[x / 40 - 1][y / 40] != 2 && vx != 1)
	{
		possible_move.add("LEFT");
	}
	
	if (x % 40 == 0 && map.beanMtx[x / 40][y / 40 - 1] != 3 && map.beanMtx[x / 40][y / 40 - 1] != 2 && vy != 1)
	{
		
		possible_move.add("UP");
	}
	

	if (possible_move.isEmpty())
		possible_move.add("No Way");
		
		return possible_move;
	}
	
	
	
	
	
	
	
}
