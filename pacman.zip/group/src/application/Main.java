package application;
	


import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;



public class Main extends Application {
	
	
	
	@Override
	public void start(Stage primaryStage) throws Exception {
			Stage window;
			//set window as primary stage
			window = primaryStage;
			
			Interface GUI_1 = new Interface();
			
			Pane root = GUI_1.first_page();
			
			Scene scene = new Scene(root,475,475);
			
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			
			window.setTitle("Pac-man");
			window.setScene(scene);
			window.setResizable(false);
			window.show();
			
	}
	
	public static void main(String[] args) {
		launch(args);
	}

}