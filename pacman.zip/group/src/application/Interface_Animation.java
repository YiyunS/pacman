package application;

import javafx.scene.Group;
import javafx.scene.shape.Arc;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;


public class Interface_Animation extends Interface_Animation_Transitions {
	
	private Interface_Animation_Elements elements =  new Interface_Animation_Elements();
	
	private Group Animation_Group =  new Group();
	
	public Group setAnimation() {
		
		 Circle bean =  elements.getBean();
		
		 Circle eye =  elements.getEye();
		
		 Rectangle Background = elements.getBackground();
		
		 Arc top_arc = elements.getTop_arc();
		
		 Arc bot_arc = elements.getBot_arc();
		 
		 
		 
		 
		super.BeanMove(bean);
		
		super.bot_face_Rotate(bot_arc);
		
		super.Top_face_Rotate(top_arc);
		 
		 
		 
		 
		Animation_Group.getChildren().addAll( Background,bean, top_arc, bot_arc, eye);
		
		return Animation_Group;
	} 

}
