package application;

import java.util.LinkedList;
import java.util.List;

public class Ghost_yiyun {
	
	//Yiyun's instances
		boolean incage = true;
		int yx = 600;
		int yy =200;
		int lastyx = 0;
		int lastyy = 0;
		boolean bad_move =false;
		point start = Movement.selectPoint(yx, yy);
		int ycount= 0;
		String Yface = null;
		int yvx = 0;
		int yvy = 0;
		int Ydirection;
		static boolean getCaught = false;
		
		
		
		void YiyunMove()
		{
			
			if(getCaught)
			{
				this.freeze();
			}
			else 
			{
//				if(buff.getBuff() && !incage)
//				{
//					this.deBuffMove();
//				}
//				else
//				{
//					if (incage)
//					{
//						this.getOutCage();
//					}
//			
//					else
//					{
						this.normalMove();
//					}
//				}
			}
		}
		
	 void normalMove() 
		{
			
			
		
			 if(bad_move)
			{
				this.YiyunRandMove();
			}
			
			else
				this.YiyunChaseMove();
			
			if(Movement.check_hit_wall(yx, yy, yvx, yvy) || Movement.check_hit_obstacles(board.arr, yx, yy, Yface))
			{
				yvy=0;
				yvx=0;
			}
			
			
		}
			
		private void YiyunRandMove()
		{
				List<String> possible_move = new LinkedList<>();
				
				
				
				if (yy % 40 == 0 && map.beanMtx[yx/40 +1][yy/40] != 3 && map.beanMtx[yx/40 +1][yy/40] != 2 && yvx != -1)
				{
					possible_move.add("RIGHT");
				}
				
				if (yx % 40 == 0 && map.beanMtx[yx/40][yy/40 + 1] != 3 && map.beanMtx[yx / 40][yy / 40 + 1] != 2 && yvy != -1)
				{
					possible_move.add("DOWN");
					
				}
				
				if (yy % 40 == 0 && map.beanMtx[yx/40 - 1][yy/40] != 3 && map.beanMtx[yx / 40 - 1][yy / 40] != 2 && yvx != 1)
				{
					possible_move.add("LEFT");
				
					
					
				}
				
				if (yx % 40 == 0 && map.beanMtx[yx / 40][yy / 40 - 1] != 3 && map.beanMtx[yx / 40][yy / 40 - 1] != 2 && yvy != 1)
				{
					
					possible_move.add("UP");
				}
				
			
				if (possible_move.isEmpty())
					possible_move.add("No Way");
				

				Ydirection = Movement.generateRandInt(0,possible_move.size()-1);
				
				
				String choose = possible_move.get(Ydirection);
				
				
				if (choose == "RIGHT" )
				{
					yvx = 1;
					yvy = 0;
	
				}
				
				else if (choose == "DOWN" )
				{
					yvx = 0;
					yvy = 1;
					
				}
				else if (choose == "LEFT" )
				{
					yvx = -1;
					yvy = 0;
				
					
				}
				else if (choose == "UP" )
				{
					yvx = 0;
					yvy = -1;
					

				}
				
				else if (choose == "No Way" && yx % 40 == 0 && yy % 40 == 0)
				{
					yvx *= -1;
					yvy *= -1;
					
				}	
				
				Yface = choose;
				
				
				if(ycount % 2 == 0)
				{yx+=yvx;
				yy+=yvy;}
				
				
				
				if(ycount % 180 == 0  )
				{
					bad_move = false;
					ycount=0;
				}
				ycount++;

		}
					
					
					
					
		private void YiyunChaseMove()
		{
			
			start = Movement.selectPoint(yx, yy);
			
			if(ycount % 40 == 0)
				{
					board.end =  Movement.selectPoint(PacMan.px, PacMan.py);
				}
			
			findPath fp = new findPath(board.arr, start, board.end);
			
			point[] path = fp.showPath();
			
			
			
			
			
			if(path.length >= 2)
			{
			if (yx > path[1].getX()*40 && yy % 40 ==0)
			{
				yvx = -1;
				yvy = 0;
				Yface = "LEFT";
			}
			
			else if (yx < path[1].getX()*40 && yy % 40 ==0)
			{
				yvx = 1;
				yvy = 0;
				Yface = "RIGHT";
			}
			
			else
			{
				yvx = 0;
			}
			
			
			
			
			if (yy > path[1].getY()*40 && yx % 40 ==0)
			{
				yvy = -1;
				yvx = 0;
				Yface="UP";
			}
			
			else if (yy < path[1].getY()*40 && yx % 40 ==0)
			{
				yvy = 1;
				yvx = 0;
				Yface="DOWN";
			}
			
			else
			{
				yvy = 0;
			}
			
			}
			
			else if(yx / 40 == PacMan.px/40 && yy/40 == PacMan.py/40)
			{
				
				
				if (yx > PacMan.px && yy % 40 ==0)
				{
					yvx = -1;
					yvy = 0;
					Yface = "LEFT";
				}
				
				else if (yx < PacMan.px && yy % 40 ==0)
				{
					yvx = 1;
					yvy = 0;
					Yface = "RIGHT";
				}
				
				
				
				
				
				
				else if (yy > PacMan.py && yx % 40 ==0)
				{
					yvy = -1;
					yvx = 0;
					Yface="UP";
					
				}
				
				else if (yy < PacMan.py && yx % 40 ==0)
				{
					yvy = 1;
					yvx = 0;
					Yface="DOWN";
				}
				
				else
				{
					yvy = 0;
					yvx = 0;
				}
				
		
			}
			
			
			
			
			if(ycount % 2 == 0)
			{yx+=yvx;
			
			yy+=yvy;
			}
			
			
			if(lastyx == yx && lastyy ==yy)
			{
				bad_move = true;
				ycount = 0;
				
			}
			
			if(ycount % 2 == 0)
			{lastyx = yx-yvx;
			
			lastyy = yy-yvy;}
		
			ycount++;
		
		}
		
		private void getOutCage() {
			
			
			yvx = -1;
			yvy = 0;

			if( yx == 360)
			{
				yvx = 0;
				yvy = -1;
			}
			
			if(ycount >= 300 && ycount % 2 ==0)
			
			{yx+=yvx;
			
			yy+=yvy;}
			
			if( yx == 360 && yy == 120)
			{
				incage = false;
			}
			
			ycount++;
		}
		private void deBuffMove() 
		{	
			

			List<String> possible_move = new LinkedList<>();
			
			
			
			if (yy % 40 == 0 && map.beanMtx[yx/40 +1][yy/40] != 3 && map.beanMtx[yx/40 +1][yy/40] != 2 && yvx != -1)
			{
				possible_move.add("RIGHT");
			}
			
			if (yx % 40 == 0 && map.beanMtx[yx/40][yy/40 + 1] != 3 && map.beanMtx[yx / 40][yy / 40 + 1] != 2 && yvy != -1)
			{
				possible_move.add("DOWN");
			}
			
			if (yy % 40 == 0 && map.beanMtx[yx/40 - 1][yy/40] != 3 && map.beanMtx[yx / 40 - 1][yy / 40] != 2 && yvx != 1)
			{
				possible_move.add("LEFT");
			}
			
			if (yx % 40 == 0 && map.beanMtx[yx / 40][yy / 40 - 1] != 3 && map.beanMtx[yx / 40][yy / 40 - 1] != 2 && yvy != 1)
			{
				
				possible_move.add("UP");
			}
			
		
			if (possible_move.isEmpty())
				possible_move.add("No Way");
			
			
			
			Ydirection = Movement.generateRandInt(0,possible_move.size()-1);
			
			
			String choose = possible_move.get(Ydirection);
			
			
			Yface = choose;
			
			if (choose == "RIGHT" )
			{
				yvx = 1;
				yvy = 0;
				
			
				
				//System.out.println("111111111");
			}
			
			else if (choose == "DOWN" )
			{
				yvx = 0;
				yvy = 1;
				
				//System.out.println("2222222222");
			}
			else if (choose == "LEFT" )
			{
				yvx = -1;
				yvy = 0;
				//System.out.println("33333");
				
			}
			else if (choose == "UP" )
			{
				yvx = 0;
				yvy = -1;
				
				//System.out.println("4444444");
			}
			
			else if (choose == "No Way" && yx % 40 == 0 && yy % 40 == 0)
			{
				yvx *= -1;
				yvy *= -1;
				
			}	
			
			if (ycount % 8 == 0)
			{yx+=yvx;
			yy+=yvy;}
			
			ycount+=1;

		}
		
		public void freeze()
		{
			yvx = 0;
			yvy = 0;
			
			yx += yvx;
			yy += yvy;
		}
		
			


}
