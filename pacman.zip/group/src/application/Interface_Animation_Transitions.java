package application;

import javafx.animation.Animation;
import javafx.animation.RotateTransition;
import javafx.animation.TranslateTransition;
import javafx.scene.shape.Arc;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

public class Interface_Animation_Transitions {
	
	public void BeanMove(Circle bean) 
	{
		TranslateTransition BeanMove =  new TranslateTransition();
		BeanMove.setDuration(Duration.seconds(2));
		BeanMove.setByX(-250);
		BeanMove.setCycleCount(Animation.INDEFINITE);
		BeanMove.setNode(bean);
		BeanMove.play();
	}

	
	public void Top_face_Rotate(Arc top_face) 
	
	{
		RotateTransition Con_ClockWise =  new RotateTransition();
		Con_ClockWise.setDuration(Duration.seconds(1));
		Con_ClockWise.setByAngle(-15);
		Con_ClockWise.setAutoReverse(true);
		Con_ClockWise.setCycleCount(Animation.INDEFINITE);
		Con_ClockWise.setNode(top_face);
		Con_ClockWise.play();
	}
	
	
	public void bot_face_Rotate(Arc bot_face)
	{
		RotateTransition ClockWise =  new RotateTransition();
		ClockWise.setDuration(Duration.seconds(1));
		ClockWise.setByAngle(15);
		ClockWise.setAutoReverse(true);
		ClockWise.setCycleCount(Animation.INDEFINITE);
		ClockWise.setNode(bot_face);
		ClockWise.play();
		
	}
	
	
}
