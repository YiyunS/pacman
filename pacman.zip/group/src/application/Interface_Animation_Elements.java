package application;

import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;


public class Interface_Animation_Elements {
	
	
	private Circle bean =  new Circle();
	
	private Circle eye =  new Circle();
	
	private Rectangle Background = new Rectangle();
	
	private Arc top_arc = new Arc(100,100,100,100,0,180);
	
	private Arc bot_arc = new Arc(100,100,100,100,180,180);


	public Circle getBean() {
		
		bean.setFill(Color.WHITE);
		bean.setRadius(10);
		bean.setLayoutX(500);
		bean.setLayoutY(250);
		
		return bean;
	}

	public Circle getEye() {
		
		eye.setFill(Color.BLACK);
		eye.setRadius(10);
		eye.setLayoutX(230);
		eye.setLayoutY(200);
		
		return eye;
	}

	public Rectangle getBackground() {
		
		Background.setFill(Color.BLACK);
		Background.setHeight(500);
		Background.setWidth(500);
		Background.setLayoutX(0);
		Background.setLayoutY(0);
		
		return Background;
	}

	public Arc getTop_arc() {
		
		top_arc.setFill(Color.YELLOW);
		top_arc.setLayoutX(130);
		top_arc.setLayoutY(150);
		
		return top_arc;
	}

	public Arc getBot_arc() {
		
		bot_arc.setFill(Color.YELLOW);
		bot_arc.setLayoutX(130);
		bot_arc.setLayoutY(150);
		
		return bot_arc;
	}

	

	
	

}
