package application;

public class buff {
	
	private static int timeRemain = 0;
	
	private static boolean buffOn = false;
	
	public static int getTime() {
		
		return timeRemain;
	}
	
	public static void TurnOn() {
		buffOn = true;
		timeRemain = 100;
	}
	
	public static void TurnOff() {
		buffOn = false;
		timeRemain = 0;
	}
	
	public void buffRun(){
		
		if(buffOn && timeRemain > 0)
		{
			timeRemain -- ;
		}
		
		if(timeRemain <= 0)
		{
			buffOn = false;
			
			Ghost_yiyun.getCaught = false;
			
			Ghost_guizhen.getCaught = false;
			
			Ghost_Ian.getCaught = false;
			
			Ghost_david.getCaught = false;
			
			Ghost_kerry.getCaught = false;
			
			timeRemain = 0;
		}
		
	}
	
	public static boolean getBuff()
	{
		return buffOn;
	}

}
