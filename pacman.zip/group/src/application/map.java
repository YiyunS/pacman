package application;

public class map 
{
	public static int[][] beanMtx;
	
	
	
	private static void setBeans()
	{ 
		
		for (int column = 0; column <19; column++)
		{
			for (int row = 0; row <17; row++)
			{
				beanMtx[column][row]= 1 ;
			}
		}
		
	}
	
	
	
	private static void setInnerWalls()
	{
		// 1st row
		beanMtx[2][1]= 2;
		beanMtx[3][1]= 2;
		beanMtx[5][1]= 2;
		beanMtx[7][1]= 2;
		//beanMtx[9][1]= 2;
		beanMtx[11][1]= 2;
		beanMtx[13][1]= 2;
		beanMtx[15][1]= 2;
		beanMtx[16][1]= 2;
		// 2nd row
		beanMtx[5][2]= 2;
		beanMtx[7][2]= 2;	
		beanMtx[9][2]= 2;
		beanMtx[11][2]= 2;
		beanMtx[13][2]= 2;
		//3rd row
		beanMtx[2][3]= 2;
		beanMtx[3][3]= 2;
		beanMtx[15][3]= 2;
		beanMtx[16][3]= 2;
		//4th row
		beanMtx[2][4]= 2;
		beanMtx[3][4]= 2;
		beanMtx[4][4]= 2;
		beanMtx[5][4]= 2;
		beanMtx[6][4]= 2;
		beanMtx[7][4]= 2;
		beanMtx[8][4]= 2;
		beanMtx[9][4]= 2;
		beanMtx[10][4]= 2;
		beanMtx[11][4]= 2;
		beanMtx[12][4]= 2;
		beanMtx[13][4]= 2;
		beanMtx[14][4]= 2;
		beanMtx[15][4]= 2;
		beanMtx[16][4]= 2;
		
		//5th row
		beanMtx[5][5]= 2;
		beanMtx[13][5]= 2;
		//6th row
		beanMtx[2][6]= 2;
		beanMtx[3][6]= 2;
		beanMtx[5][6]= 2;
		beanMtx[6][6]= 2; 
		beanMtx[7][6]= 2;
		beanMtx[8][6]= 2;
		beanMtx[9][6]= 2;
		beanMtx[10][6]= 2;
		beanMtx[11][6]= 2;
		beanMtx[12][6]= 2;
		beanMtx[13][6]= 2;
		beanMtx[15][6]= 2;
		//beanMtx[16][6]= 2;
		beanMtx[17][6]= 2;
		//7th row no wall
		beanMtx[2][7]= 2;
		beanMtx[3][7]= 2;
		//beanMtx[15][7]= 2;
		//beanMtx[16][7]= 2;
		beanMtx[17][7]= 2;
		//8th row
		beanMtx[5][8]= 2;
		beanMtx[7][8]= 2;
		beanMtx[8][8]= 2;
		beanMtx[9][8]= 2;
		beanMtx[10][8]= 2;
		beanMtx[11][8]= 2;
		beanMtx[13][8]= 2;
		beanMtx[15][8]= 2;
		//9th row
		beanMtx[2][9]= 2;
		beanMtx[3][9]= 2;
		beanMtx[9][9]= 2;
		//beanMtx[15][9]= 2;
		//beanMtx[16][9]= 2;
		beanMtx[17][9]= 2;
		//10th row
		beanMtx[2][10]= 2;
		beanMtx[3][10]= 2;
		beanMtx[5][10]= 2;
		beanMtx[6][10]= 2;
		beanMtx[7][10]= 2;
		beanMtx[9][10]= 2;
		beanMtx[11][10]= 2;
		beanMtx[12][10]= 2;
		beanMtx[13][10]= 2;
		beanMtx[15][10]= 2;
		//beanMtx[16][10]= 2;
		beanMtx[17][10]= 2;
		//11th row nothing	
		//12th row
		beanMtx[1][12]= 2; 
		beanMtx[3][12]= 2;
		beanMtx[5][12]= 2;
		beanMtx[7][12]= 2; 
		beanMtx[8][12]= 2; 
		beanMtx[9][12]= 2; 
		beanMtx[10][12]= 2;
		beanMtx[11][12]= 2; 
		beanMtx[13][12]= 2; 
		beanMtx[15][12]= 2;
		beanMtx[17][12]= 2;
		//13th row
		beanMtx[1][13]= 2; 
		//beanMtx[3][13]= 2; 
		//beanMtx[5][13]= 2; 
		beanMtx[9][13]= 2;
		//beanMtx[13][13]= 2; 
		beanMtx[17][13]= 2;
		//14th row
		beanMtx[1][14]= 2; 
		beanMtx[3][14]= 2; 
		beanMtx[5][14]= 2; 
		beanMtx[7][14]= 2;
		beanMtx[11][14]= 2; 
		beanMtx[13][14]= 2;
		beanMtx[15][14]= 2; 
		beanMtx[17][14]= 2; 
		//15th row
		beanMtx[7][15]= 2; 
		beanMtx[8][15]= 2; 
		beanMtx[9][15]= 2; 
		beanMtx[10][15]= 2;
		beanMtx[11][15]= 2; 
		
	}
	private static  void setSurroundWalls()
	{
		for (int column = 0; column < 19; column++)
		{
			for (int row = 0; row < 17; row++)
			{
				if( column == 0 ||column == 18|| row == 16 || row == 0)
					beanMtx[column][row] = 3;
			}
		}
	}
	private static void setEmpty()
	{
		beanMtx[9][14] = 0;
		
		
		beanMtx[6][5] = 0;
		beanMtx[7][5] = 0;
		beanMtx[8][5] = 0;
		beanMtx[9][5] = 0;
		beanMtx[10][5] = 0;
		beanMtx[11][5] = 0;
		beanMtx[12][5] = 0;
		
	}
	
	private static void setBigBeans()
	{
		beanMtx[4][1] = 4;
		beanMtx[1][15] = 4;
		beanMtx[9][1]= 4;
		beanMtx[17][1] = 4;
		beanMtx[17][11] = 4;
	}
	
	public static int[][] reset()
	{	beanMtx = new int[19][17] ;
		setBeans();
		setBigBeans();
		setInnerWalls();
		setSurroundWalls();
		setEmpty();
		return beanMtx;
	}
	
	
	



	
}

//0 empty
//1 beans
//2 surround wall
//3 inner wall
//4 big beans
