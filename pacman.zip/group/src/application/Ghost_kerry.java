package application;

import java.util.LinkedList;
import java.util.List;

public class Ghost_kerry {
		
		boolean incage = true;
		 int kx = 240;
		 int ky = 200;
		 String Kface = null;
		 int kvx = 0;
		 int kvy = 0;
		 int Kdirection;
		 int kcount = 0;
		 public static boolean getCaught = false;
		
		void KerryMove() 
		{	
			if(getCaught)
			{
				this.freeze();
			}
			else
				{
					if(buff.getBuff() && !incage)
					{
						this.deBuffMove();
					}
			
					else
					{
						if (incage)
						{
							this.getOutCage();
						}
			
						else
						{
							this.normalMove();
						}
					}
				}
		}
		
		
		private void normalMove() {	
			

			List<String> possible_move = new LinkedList<>();
			
			
			
			if (ky % 40 == 0 && map.beanMtx[kx/40 +1][ky/40] != 3 && map.beanMtx[kx/40 +1][ky/40] != 2 && kvx != -1)
			{
				possible_move.add("RIGHT");
			}
			
			if (kx % 40 == 0 && map.beanMtx[kx/40][ky/40 + 1] != 3 && map.beanMtx[kx / 40][ky / 40 + 1] != 2 && kvy != -1)
			{
				possible_move.add("DOWN");
			}
			
			if (ky % 40 == 0 && map.beanMtx[kx/40 - 1][ky/40] != 3 && map.beanMtx[kx / 40 - 1][ky / 40] != 2 && kvx != 1)
			{
				possible_move.add("LEFT");
			}
			
			if (kx % 40 == 0 && map.beanMtx[kx / 40][ky / 40 - 1] != 3 && map.beanMtx[kx / 40][ky / 40 - 1] != 2 && kvy != 1)
			{
				
				possible_move.add("UP");
			}
			
		
			if (possible_move.isEmpty())
				possible_move.add("No Way");
			
			
			
			Kdirection = Movement.generateRandInt(0,possible_move.size()-1);
			
			String choose = possible_move.get(Kdirection);
			
			Kface = choose;
			
			if (choose == "RIGHT" )
			{
				kvx = 1;
				kvy = 0;
				
			
				
				//System.out.println("111111111");
			}
			
			else if (choose == "DOWN" )
			{
				kvx = 0;
				kvy = 1;
				
				//System.out.println("2222222222");
			}
			else if (choose == "LEFT" )
			{
				kvx = -1;
				kvy = 0;
				//System.out.println("33333");
				
			}
			else if (choose == "UP" )
			{
				kvx = 0;
				kvy = -1;
				
				//System.out.println("4444444");
			}
			
			else if (choose == "No Way" && kx % 40 == 0 && ky % 40 == 0)
			{
				kvx *= -1;
				kvy *= -1;
				
			}	
			
			if (kcount % 4 == 0 )
			{kx+=kvx;
			ky+=kvy;}
			
			kcount ++;

		}
		
		private void getOutCage() {
			
			kvx = 1;
			kvy = 0;
			Kface = "RIGHT";
			
			if(kx == 360)
			{
				kvx = 0;
				kvy = 1;
				Kface = "DOWN";
			}
			
			if(kcount % 2 ==0)
			
			{kx+=kvx;
			
			ky+=kvy;}
			
			if( kx == 360 && ky == 280)
			{
				incage = false;
			}
			
			kcount++;
		}
		
		private void deBuffMove() 
{	
			

			List<String> possible_move = new LinkedList<>();
			
			
			
			if (ky % 40 == 0 && map.beanMtx[kx/40 +1][ky/40] != 3 && map.beanMtx[kx/40 +1][ky/40] != 2 && kvx != -1)
			{
				possible_move.add("RIGHT");
			}
			
			if (kx % 40 == 0 && map.beanMtx[kx/40][ky/40 + 1] != 3 && map.beanMtx[kx / 40][ky / 40 + 1] != 2 && kvy != -1)
			{
				possible_move.add("DOWN");
			}
			
			if (ky % 40 == 0 && map.beanMtx[kx/40 - 1][ky/40] != 3 && map.beanMtx[kx / 40 - 1][ky / 40] != 2 && kvx != 1)
			{
				possible_move.add("LEFT");
			}
			
			if (kx % 40 == 0 && map.beanMtx[kx / 40][ky / 40 - 1] != 3 && map.beanMtx[kx / 40][ky / 40 - 1] != 2 && kvy != 1)
			{
				
				possible_move.add("UP");
			}
			
		
			if (possible_move.isEmpty())
				possible_move.add("No Way");
			
			
			
			Kdirection = Movement.generateRandInt(0,possible_move.size()-1);
			
			String choose = possible_move.get(Kdirection);
			
			Kface = choose;
			
			if (choose == "RIGHT" )
			{
				kvx = 1;
				kvy = 0;
				
			
				
				//System.out.println("111111111");
			}
			
			else if (choose == "DOWN" )
			{
				kvx = 0;
				kvy = 1;
				
				//System.out.println("2222222222");
			}
			else if (choose == "LEFT" )
			{
				kvx = -1;
				kvy = 0;
				//System.out.println("33333");
				
			}
			else if (choose == "UP" )
			{
				kvx = 0;
				kvy = -1;
				
				//System.out.println("4444444");
			}
			
			else if (choose == "No Way" && kx % 40 == 0 && ky % 40 == 0)
			{
				kvx *= -1;
				kvy *= -1;
				
			}	
			
			if (kcount % 8 == 0 )
			{kx+=kvx;
			ky+=kvy;}
			
			kcount ++;

		}
		public void freeze()
		{
			kvx = 0;
			kvy = 0;
			
			kx += kvx;
			ky += kvy;
		}

}
