package application;

import java.util.LinkedList;
import java.util.List;

public class Ghost_Ian {
	
	 boolean incage = true;
	 int ix = 360;
	 int iy = 200;
	 String Iface = null;
	 int ivx = 0;
	 int ivy = 0;
	 int idirection;
	 int icount = 0;
	 public static boolean getCaught = false;
	
	void ianMove() 
	{	
		if (getCaught)
		{
			this.freeze();
		}
		
		else
		{
			if(buff.getBuff() && !incage)
			{
				this.deBuffMove();
			}
		
			else
			{
				if (incage)
				{
					this.getOutCage();
				}
		
				else
				{
					this.normalMove();
				}
			}
		}
	}
	
	
	private void normalMove() {	
		

		List<String> possible_move = new LinkedList<>();
		
		
		
		if (iy % 40 == 0 && map.beanMtx[ix/40 +1][iy/40] != 3 && map.beanMtx[ix/40 +1][iy/40] != 2 && ivx != -1)
		{
			possible_move.add("RIGHT");
		}
		
		if (ix % 40 == 0 && map.beanMtx[ix/40][iy/40 + 1] != 3 && map.beanMtx[ix / 40][iy / 40 + 1] != 2 && ivy != -1)
		{
			possible_move.add("DOWN");
		}
		
		if (iy % 40 == 0 && map.beanMtx[ix/40 - 1][iy/40] != 3 && map.beanMtx[ix / 40 - 1][iy / 40] != 2 && ivx != 1)
		{
			possible_move.add("LEFT");
		}
		
		if (ix % 40 == 0 && map.beanMtx[ix / 40][iy / 40 - 1] != 3 && map.beanMtx[ix / 40][iy / 40 - 1] != 2 && ivy != 1)
		{
			
			possible_move.add("UP");
		}
		
	
		if (possible_move.isEmpty())
			possible_move.add("No Way");
		
		
		
		idirection = Movement.generateRandInt(0,possible_move.size()-1);
		
		String choose = possible_move.get(idirection);
		
		Iface = choose;
		
		if (choose == "RIGHT" )
		{
			ivx = 1;
			ivy = 0;
			
		
			
			//System.out.println("111111111");
		}
		
		else if (choose == "DOWN" )
		{
			ivx = 0;
			ivy = 1;
			
			//System.out.println("2222222222");
		}
		else if (choose == "LEFT" )
		{
			ivx = -1;
			ivy = 0;
			//System.out.println("33333");
			
		}
		else if (choose == "UP" )
		{
			ivx = 0;
			ivy = -1;
			
			//System.out.println("4444444");
		}
		
		else if (choose == "No Way" && ix % 40 == 0 && iy % 40 == 0)
		{
			ivx *= -1;
			ivy *= -1;
			
		}	
		 
		 
		 if(board.Dot>=100 )
		 {	
			 if(icount % 4 == 0)
			 { ix+=ivx;
			 iy+=ivy;}
		 }
		 
		 else if (board.Dot >= 50 )
		 {
			if(icount % 3 == 0)
			 {ix+=ivx;
			 iy+=ivy;}
		 }
		 else if (board.Dot >= 10 )
		 {
			if(icount % 2 == 0)
			 {ix+=ivx;
			 iy+=ivy;}
		 }
		 
		 else
		 {	
			 {ix+=ivx;
			 iy+=ivy;}
		 }
		
		icount ++;

	}
	
	private void getOutCage() {
		
		
		ivx = 0;
		ivy = -1;
		Iface = "UP";
		
		
		if(icount % 2 ==0)
		
		{ix+=ivx;
		
		iy+=ivy;}
		
		if( ix == 360 && iy == 120)
		{
			incage = false;
		}
		
		icount++;
	}
	
	private void deBuffMove() 
{	
		

		List<String> possible_move = new LinkedList<>();
		
		
		
		if (iy % 40 == 0 && map.beanMtx[ix/40 +1][iy/40] != 3 && map.beanMtx[ix/40 +1][iy/40] != 2 && ivx != -1)
		{
			possible_move.add("RIGHT");
		}
		
		if (ix % 40 == 0 && map.beanMtx[ix/40][iy/40 + 1] != 3 && map.beanMtx[ix / 40][iy / 40 + 1] != 2 && ivy != -1)
		{
			possible_move.add("DOWN");
		}
		
		if (iy % 40 == 0 && map.beanMtx[ix/40 - 1][iy/40] != 3 && map.beanMtx[ix / 40 - 1][iy / 40] != 2 && ivx != 1)
		{
			possible_move.add("LEFT");
		}
		
		if (ix % 40 == 0 && map.beanMtx[ix / 40][iy / 40 - 1] != 3 && map.beanMtx[ix / 40][iy / 40 - 1] != 2 && ivy != 1)
		{
			
			possible_move.add("UP");
		}
		
	
		if (possible_move.isEmpty())
			possible_move.add("No Way");
		
		
		
		idirection = Movement.generateRandInt(0,possible_move.size()-1);
		
		String choose = possible_move.get(idirection);
		
		Iface = choose;
		
		if (choose == "RIGHT" )
		{
			ivx = 1;
			ivy = 0;
			
		
			
			//System.out.println("111111111");
		}
		
		else if (choose == "DOWN" )
		{
			ivx = 0;
			ivy = 1;
			
			//System.out.println("2222222222");
		}
		else if (choose == "LEFT" )
		{
			ivx = -1;
			ivy = 0;
			//System.out.println("33333");
			
		}
		else if (choose == "UP" )
		{
			ivx = 0;
			ivy = -1;
			
			//System.out.println("4444444");
		}
		
		else if (choose == "No Way" && ix % 40 == 0 && iy % 40 == 0)
		{
			ivx *= -1;
			ivy *= -1;
			
		}	
		
			 
		if(icount % 4 == 0)
		{ 
			ix+=ivx;
			iy+=ivy;
		}
	
		
		icount ++;

		}
	
	public void freeze()
	{
		ivx = 0;
		ivy = 0;
		
		ix += ivx;
		iy += ivy;
	}
	
	
	}